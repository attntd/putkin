import QtQuick

QtObject {
    id: root
    required property var service
    required property var loader
    readonly property var screen: service.screen
    readonly property bool loaded: loader.active
    readonly property var window: loader.active ? loader.item : null
    function sync(): void { loader.activeAsync = service.visible; }
    readonly property Connections changes: Connections {
        target: root.service
        function onVisibleChanged(): void { root.sync(); }
    }
    Component.onCompleted: sync()
}
