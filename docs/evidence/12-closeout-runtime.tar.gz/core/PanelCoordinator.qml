import QtQuick

QtObject {
    id: root
    required property var screens
    required property var monitorService
    required property var barFocus
    required property var settings
    // A single assignment publishes a complete request to the host.
    property var session: null
    property string lastError: ""
    readonly property string activeId: session ? session.id : ""
    readonly property string screenName: session ? session.screen.name : ""

    function chooseScreen(): var {
        return screens.find(screen => screen.name === monitorService.focusedMonitorName)
            || (screens.length > 0 ? screens[0] : null);
    }

    function open(id: string, screen: var, invoker: var): bool {
        return present(id, screen, invoker, null);
    }

    function openTray(item: var, screen: var, invoker: var): bool {
        if (!item || !item.hasMenu || !item.menu) return false;
        return present("trayMenu", screen, invoker, item);
    }

    function present(id: string, screen: var, invoker: var, item: var): bool {
        if (id !== "quickSettings" && id !== "settings" && id !== "trayOverflow" && id !== "trayMenu" && id !== "power") {
            lastError = "unknown-surface";
            return false;
        }
        const target = screen || chooseScreen();
        if (!target || screens.indexOf(target) < 0) {
            lastError = "screen-unavailable";
            return false;
        }
        if (target.width <= Metrics.panelGap * 2
                || target.height <= Metrics.barHeight + Metrics.panelGap * 2) {
            lastError = "screen-too-small";
            return false;
        }
        const previous = session && session.screen === target ? session : null;
        const restoreBar = previous ? previous.restoreBar : barFocus.screenName === target.name;
        const origin = invoker || (previous ? previous.invoker : null);
        const tray = id === "trayMenu" || id === "trayOverflow";
        const anchorRight = tray && invoker ? invoker.mapToItem(null, invoker.width, 0).x
            : tray && previous && previous.anchorRight ? previous.anchorRight : target.width - Metrics.panelGap;
        if (!session || session.id !== id || session.screen !== target) {
            settings.cancelEdit();
            if (id === "settings") settings.beginEdit();
        }
        barFocus.close();
        lastError = "";
        session = { id: id, screen: target, invoker: origin, restoreBar: restoreBar, trayItem: item, anchorRight: anchorRight,
            returnToOverflow: id === "trayMenu" && previous !== null
                && (previous.id === "trayOverflow" || previous.returnToOverflow === true) };
        return true;
    }

    function toggle(id: string, screen: var, invoker: var): bool {
        const target = screen || chooseScreen();
        if (session && session.id === id && session.screen === target) {
            close(true);
            return true;
        }
        return open(id, target, invoker);
    }

    function close(restoreFocus: bool): void {
        const previous = session;
        settings.cancelEdit();
        session = null;
        if (restoreFocus && previous && previous.restoreBar
                && screens.indexOf(previous.screen) >= 0)
            barFocus.resume(previous.screen.name, previous.invoker);
    }

    function validate(): void {
        if (session && screens.indexOf(session.screen) < 0)
            close(false);
    }

    onScreensChanged: validate()
    readonly property Connections barChanges: Connections {
        target: root.barFocus
        function onEntered(_name: string): void { root.close(false); }
    }
}
