pragma Singleton

import QtQuick

QtObject {
    readonly property int radius: 0
    readonly property int borderWidth: 1
    readonly property int focusWidth: 2
    readonly property int focusOffset: 4
    readonly property int space4: 4
    readonly property int space8: 8
    readonly property int space12: 12
    readonly property int space16: 16
    readonly property int space24: 24
    readonly property int controlHeight: 36
    readonly property int barHeight: 32
    readonly property int workspaceWidth: 48
    readonly property int workspaceMaxWidth: 480
    readonly property int barStatusReserve: 40
    readonly property int trayButtonWidth: 36
    readonly property int trayVisibleLimit: 4
    readonly property int fontSize: 13
    readonly property int smallFontSize: 12
    readonly property int tooltipDelay: 600
    readonly property int panelWidth: 360
    readonly property int panelGap: 8
    readonly property int panelFade: 120
    readonly property int osdWidth: 280
    readonly property int osdHeight: 76
    readonly property int osdTimeout: 1500
    readonly property int toastWidth: 360
    readonly property int toastMinHeight: 132
    readonly property int toastMaxHeight: 280
    readonly property int toastImageHeight: 100
}
