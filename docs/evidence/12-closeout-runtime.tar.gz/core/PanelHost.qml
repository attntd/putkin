import QtQuick

QtObject {
    id: root
    required property var coordinator
    required property var loader
    property var audio: null
    property var brightness: null
    property var nightLight: null
    property var battery: null
    property var tray: null
    property var network: null
    property var bluetooth: null
    property var notifications: null
    property var sessionService: null
    property var notificationController: null
    property Component trayMenuComponent: null
    property real anchorRight: 0
    property var screen: null
    property string surfaceId: ""
    property bool interactive: false
    readonly property bool loaded: loader.active
    // Never read item during asynchronous incubation.
    readonly property var window: loader.active ? loader.item : null
    readonly property int availableWidth: screen ? Math.max(1, screen.width - Metrics.panelGap * 2) : 1
    readonly property int availableHeight: screen ? Math.max(1, screen.height - Metrics.barHeight - Metrics.panelGap * 2) : 1
    readonly property real rightEdge: surfaceId === "trayMenu" || surfaceId === "trayOverflow"
        ? anchorRight : screen ? screen.width - Metrics.panelGap : 0
    readonly property real surfaceX: surfaceId === "power" && screen ? (screen.width - Math.min(Metrics.panelWidth, availableWidth)) / 2
        : Math.max(Metrics.panelGap, Math.min(availableWidth + Metrics.panelGap
        - Math.min(Metrics.panelWidth, availableWidth), rightEdge - Math.min(Metrics.panelWidth, availableWidth)))

    function surfaceY(height: real): real {
        return surfaceId === "power" && screen ? Math.max(Metrics.barHeight + Metrics.panelGap, (screen.height - height) / 2)
            : Metrics.barHeight + Metrics.panelGap;
    }

    function sync(): void {
        const session = coordinator.session;
        if (session) {
            if (brightness && session.id === "quickSettings") brightness.refresh();
            if (nightLight && session.id === "quickSettings") nightLight.refresh();
            if (sessionService && (session.id === "quickSettings" || session.id === "power")) sessionService.refresh();
            release.stop();
            if (screen !== session.screen) {
                interactive = false;
                loader.activeAsync = false;
            }
            screen = session.screen;
            surfaceId = session.id;
            anchorRight = session.anchorRight;
            interactive = true;
            loader.activeAsync = true;
        } else {
            interactive = false;
            release.restart();
        }
    }

    readonly property Timer release: Timer {
        interval: Theme.reducedMotion ? 0 : Metrics.panelFade
        onTriggered: {
            if (!root.interactive) {
                root.loader.activeAsync = false;
                root.screen = null;
                root.surfaceId = "";
            }
        }
    }
    readonly property Connections changes: Connections {
        target: root.coordinator
        function onSessionChanged(): void { root.sync(); }
    }
    Component.onCompleted: sync()
}
