import QtQml
import Quickshell.Io

QtObject {
    id: root
    required property var coordinator
    readonly property IpcHandler handler: IpcHandler {
        target: "ui"
        function openQuickSettings(): string {
            return root.coordinator.open("quickSettings", null, null) ? "ok" : root.coordinator.lastError;
        }
        function toggleQuickSettings(): string {
            return root.coordinator.toggle("quickSettings", null, null) ? "ok" : root.coordinator.lastError;
        }
        function openSettings(): string {
            return root.coordinator.open("settings", null, null) ? "ok" : root.coordinator.lastError;
        }
        function closePanels(): void { root.coordinator.close(true); }
    }
}
