import QtQuick
import QtQuick.Controls.Basic as Controls
import "../core"

Controls.TextField {
    id: root
    property bool invalid: false
    signal ensureVisible(Item item)
    implicitHeight: Metrics.controlHeight
    padding: Metrics.space8
    font.family: Theme.fontFamily
    font.pixelSize: Metrics.fontSize
    color: Theme.text
    selectionColor: Theme.accent
    selectedTextColor: Theme.accentText
    placeholderTextColor: Theme.textMuted
    selectByMouse: true
    onActiveFocusChanged: { if (activeFocus) ensureVisible(root); }
    background: Rectangle {
        color: Theme.background
        border.color: root.invalid ? Theme.error : Theme.border
        border.width: Metrics.borderWidth
        Rectangle {
            objectName: "focusIndicator"
            anchors.fill: parent
            anchors.margins: -Metrics.focusOffset
            color: "transparent"
            border.color: Theme.focus
            border.width: Metrics.focusWidth
            visible: root.activeFocus
        }
    }
}
