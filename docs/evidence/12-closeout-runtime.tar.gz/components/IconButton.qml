import QtQuick
import "../core"

Button {
    id: root

    required property string accessibleName
    required property url iconSource

    implicitWidth: Metrics.controlHeight
    padding: Metrics.space8
    text: accessibleName
    tooltip: accessibleName
    Accessible.name: accessibleName

    contentItem: Image {
        source: root.iconSource
        sourceSize: Qt.size(20, 20)
        fillMode: Image.PreserveAspectFit

        Text {
            anchors.centerIn: parent
            text: "?"
            font: root.font
            color: root.foreground
            visible: parent.status === Image.Error
        }
    }
}
