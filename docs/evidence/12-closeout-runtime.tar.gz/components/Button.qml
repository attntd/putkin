import QtQuick
import QtQuick.Controls.Basic as Controls
import "../core"

Controls.Button {
    id: root

    property string tooltip: text
    property bool windowedTooltip: false
    property color foreground: !enabled ? Theme.textDisabled : (highlighted || checked) ? Theme.accentText : Theme.text
    property color fillColor: !enabled ? Theme.backgroundStrong : (highlighted || checked) ? Theme.accent : down ? Theme.border : hovered ? Theme.surfaceHover : Theme.surface

    implicitWidth: Math.max(implicitContentWidth + leftPadding + rightPadding, Metrics.controlHeight)
    implicitHeight: Metrics.controlHeight
    padding: Metrics.space12
    verticalPadding: Metrics.space8
    hoverEnabled: true
    focusPolicy: Qt.StrongFocus
    font.family: Theme.fontFamily
    font.pixelSize: Metrics.fontSize
    Accessible.name: text

    contentItem: Text {
        text: root.text
        font: root.font
        color: root.foreground
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
    }
    background: Rectangle {
        radius: Metrics.radius
        color: root.fillColor
        border.width: Metrics.borderWidth
        border.color: root.down ? Theme.text : (root.highlighted || root.checked) ? Theme.accentBorder : Theme.border

        Rectangle {
            objectName: "focusIndicator"
            anchors.fill: parent
            anchors.margins: -Metrics.focusOffset
            radius: Metrics.radius
            color: "transparent"
            border.width: Metrics.focusWidth
            border.color: Theme.focus
            visible: root.visualFocus
        }
    }
    ToolTip {
        objectName: "tooltip"
        text: root.tooltip
        popupType: root.windowedTooltip ? Controls.Popup.Window : Controls.Popup.Item
        visible: root.enabled && root.hovered && text.length > 0
    }
}
