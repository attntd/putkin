//@ pragma Env QS_PIPEWIRE_IMMEDIATE_RECONNECT = 1
pragma ComponentBehavior: Bound

import QtQuick
import Quickshell
import "core"
import "services"
import "modules/bar"
import "modules/quicksettings" as Panels
import "modules/osd"
import "modules/notifications"
import "modules/wallpaper"

ShellRoot {
    SettingsFile { id: settingsFile }
    Settings { id: settings; storage: settingsFile }
    Binding { target: Theme; property: "appearance"; value: settings.effective }
    WallpaperService { id: wallpaperService; selection: Quickshell.env("PUTKIN_WALLPAPER") || "" }
    WallpaperWindows { service: wallpaperService }
    HyprlandService { id: hyprland }
    PipewireBackend { id: pipewire }
    AudioService { id: audioService; backend: pipewire }
    AudioIpc { audio: audioService }
    BrightnessBackend { id: backlight }
    BrightnessService { id: brightnessService; backend: backlight }
    BrightnessIpc { brightness: brightnessService }
    NightLightBackend { id: nightLightBackend }
    NightLightService { id: nightLightService; backend: nightLightBackend }
    SessionBackend { id: sessionBackend }
    SessionService { id: sessionService; backend: sessionBackend }
    SessionIpc { service: sessionService; coordinator: panels }
    SessionController { service: sessionService; coordinator: panels; brightness: brightnessService }
    UPowerBackend { id: powerBackend }
    BatteryService { id: batteryService; backend: powerBackend }
    TrayService { id: trayService }
    NetworkBackend { id: networkBackend }
    NetworkService { id: networkService; backend: networkBackend }
    BluetoothBackend { id: bluetoothBackend }
    BluetoothService { id: bluetoothService; backend: bluetoothBackend }
    NotificationBackend { id: notificationBackend }
    NotificationService { id: notifications; backend: notificationBackend; screens: Quickshell.screens; monitorService: hyprland }
    NotificationFocus { id: notificationFocus; service: notifications; panels: panels; barFocus: barFocus }
    NotificationIpc { service: notifications; controller: notificationFocus }
    NotificationWindows { service: notifications; controller: notificationFocus; panels: panels }
    SystemClock { id: clock; precision: SystemClock.Minutes }
    BarFocus {
        id: barFocus
        service: hyprland
        screenNames: Quickshell.screens.map(screen => screen.name)
    }
    BarIpc { controller: barFocus }
    PanelCoordinator {
        id: panels
        screens: Quickshell.screens
        monitorService: hyprland
        barFocus: barFocus
        settings: settings
    }
    PanelIpc { coordinator: panels }
    PanelHost {
        id: panelHost
        coordinator: panels
        loader: panelLoader
        audio: audioService
        brightness: brightnessService
        nightLight: nightLightService
        battery: batteryService
        tray: trayService
        network: networkService
        bluetooth: bluetoothService
        notifications: notifications
        sessionService: sessionService
        notificationController: notificationFocus
        trayMenuComponent: Component { TrayMenuAdapter {} }
    }
    LazyLoader { id: panelLoader; Panels.InteractivePanelWindow { host: panelHost } }
    OsdService { id: osd; audio: audioService; brightness: brightnessService; screens: Quickshell.screens; monitorService: hyprland; panelHost: panelHost }
    OsdHost { id: osdHost; service: osd; loader: osdLoader }
    LazyLoader { id: osdLoader; OsdWindow { host: osdHost } }
    Variants {
        model: Quickshell.screens
        BarWindow {
            required property ShellScreen modelData
            screen: modelData
            service: hyprland
            controller: barFocus
            panels: panels
            audio: audioService
            battery: batteryService
            tray: trayService
            network: networkService
            date: clock.date
        }
    }
}
