import QtQuick
import "../../core"
import "../../components" as UI

Column {
    id: root
    required property var settings
    spacing: Metrics.space16
    signal requested(string surface)
    signal dismissed()
    signal ensureVisible(Item item)
    function focusInitial(): void { back.forceActiveFocus(Qt.TabFocusReason); }
    function dismissOrCollapse(): void { dismissed(); }

    UI.PanelText { width: parent.width; text: qsTr("Wygląd"); font.bold: true }
    Row {
        width: parent.width
        spacing: Metrics.space12
        UI.NavigationButton {
            id: back
            objectName: "backButton"
            width: (parent.width - parent.spacing) / 2
            text: qsTr("Wstecz")
            rightTarget: close
            downTarget: primary.firstControl
            KeyNavigation.tab: close
            KeyNavigation.backtab: cancel
            onClicked: root.requested("quickSettings")
            onEnsureVisible: item => root.ensureVisible(item)
        }
        UI.NavigationButton {
            id: close
            objectName: "closeButton"
            width: back.width
            text: qsTr("Zamknij")
            leftTarget: back
            downTarget: primary.firstControl
            KeyNavigation.tab: primary.firstControl
            KeyNavigation.backtab: back
            onClicked: root.dismissed()
            onEnsureVisible: item => root.ensureVisible(item)
        }
    }
    UI.PanelText {
        objectName: "appearanceDescription"
        width: parent.width
        text: qsTr("Catppuccin Mocha · podgląd na żywo na wszystkich monitorach.")
        color: Theme.textMuted
        font.pixelSize: Metrics.smallFontSize
    }
    ColorEditor {
        id: primary
        width: parent.width
        settings: root.settings
        colorKey: "accent"
        title: qsTr("Akcent główny")
        enabled: root.settings.ready && !root.settings.saving
        upTarget: back
        downTarget: secondary.firstControl
        onEnsureVisible: item => root.ensureVisible(item)
    }
    ColorEditor {
        id: secondary
        width: parent.width
        settings: root.settings
        colorKey: "accentSecondary"
        title: qsTr("Akcent dodatkowy")
        enabled: primary.enabled
        upTarget: primary.field
        downTarget: motion
        onEnsureVisible: item => root.ensureVisible(item)
    }
    UI.NavigationButton {
        id: motion
        objectName: "reducedMotionButton"
        width: parent.width
        enabled: primary.enabled
        text: (root.settings.draft.reducedMotion ? "[✓] " : "[ ] ") + qsTr("Ogranicz ruch")
        checked: root.settings.draft.reducedMotion
        onClicked: root.settings.setReducedMotion(!root.settings.draft.reducedMotion)
        upTarget: secondary.field
        downTarget: reset
        KeyNavigation.tab: reset
        KeyNavigation.backtab: secondary.field
        onEnsureVisible: item => root.ensureVisible(item)
    }
    UI.NavigationButton {
        id: reset
        objectName: "resetButton"
        width: parent.width
        text: qsTr("Przywróć domyślne")
        enabled: primary.enabled
        upTarget: motion
        downTarget: reload.visible ? reload : save.enabled ? save : cancel
        KeyNavigation.tab: reload.visible ? reload : save
        KeyNavigation.backtab: motion
        onClicked: root.settings.resetDraft()
        onEnsureVisible: item => root.ensureVisible(item)
    }
    UI.PanelText {
        objectName: "settingsProblem"
        width: parent.width
        visible: text.length > 0
        text: [root.settings.readProblem,
            root.settings.conflict ? qsTr("Plik zmienił się poza formularzem. Twój podgląd pozostaje aktywny. Wczytaj plik, aby odrzucić podgląd i przyjąć zmiany.") : "",
            root.settings.saveProblem].filter(message => message.length > 0).join("\n")
        color: Theme.error
        font.pixelSize: Metrics.smallFontSize
    }
    UI.NavigationButton {
        id: reload
        objectName: "reloadSettingsButton"
        width: parent.width
        visible: root.settings.conflict || root.settings.readProblem.length > 0
        enabled: !root.settings.saving
        text: qsTr("Wczytaj plik i odrzuć podgląd")
        upTarget: reset
        downTarget: save.enabled ? save : cancel
        KeyNavigation.tab: save
        KeyNavigation.backtab: reset
        onClicked: { root.settings.useLatest(); reset.forceActiveFocus(Qt.TabFocusReason); }
        onEnsureVisible: item => root.ensureVisible(item)
    }
    UI.PanelText {
        objectName: "settingsNotice"
        width: parent.width
        visible: text.length > 0
        text: root.settings.saving ? qsTr("Zapisywanie…") : root.settings.notice
        color: Theme.textMuted
        font.pixelSize: Metrics.smallFontSize
    }
    Row {
        width: parent.width
        spacing: Metrics.space12
        UI.NavigationButton {
            id: save
            objectName: "saveSettingsButton"
            width: (parent.width - parent.spacing) / 2
            text: qsTr("Zapisz")
            highlighted: true
            enabled: root.settings.canSave
            rightTarget: cancel
            upTarget: reload.visible ? reload : reset
            KeyNavigation.tab: cancel
            KeyNavigation.backtab: reload.visible ? reload : reset
            onClicked: root.settings.save()
            onEnsureVisible: item => root.ensureVisible(item)
        }
        UI.NavigationButton {
            id: cancel
            objectName: "cancelSettingsButton"
            width: save.width
            text: qsTr("Anuluj")
            leftTarget: save
            upTarget: reload.visible ? reload : reset
            KeyNavigation.tab: back
            KeyNavigation.backtab: save
            onClicked: root.dismissed()
            onEnsureVisible: item => root.ensureVisible(item)
        }
    }
}
