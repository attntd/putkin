pragma ComponentBehavior: Bound
import QtQuick
import "../../core"
import "../../components" as UI

Column {
    id: root
    required property var handle
    required property Component menuComponent
    required property Item backControl
    property var opener: null
    property string title: ""
    property var selected: null
    property bool hadFocus: false
    property bool focusedOnce: false
    readonly property var entries: opener && opener.entries ? opener.entries.values : []
    signal descend(var entry)
    signal activated(var entry)
    signal backRequested()
    signal ensureVisible(Item item)
    signal entriesUpdated()
    width: parent ? parent.width : 0
    spacing: Metrics.space4

    function focusEntry(entry: var): void {
        const index = entries.indexOf(entry);
        const button = index >= 0 ? buttons.itemAt(index) : null;
        if (button && button.enabled) button.forceActiveFocus(Qt.TabFocusReason);
        else moveSelection(-1, 1);
    }
    function moveSelection(index: int, delta: int): void {
        for (let i = index + delta; i >= 0 && i < entries.length; i += delta) {
            const button = buttons.itemAt(i);
            if (button && button.enabled) {
                button.forceActiveFocus(Qt.TabFocusReason);
                return;
            }
        }
        backControl.forceActiveFocus(Qt.TabFocusReason);
    }
    function focusInitial(): void { focusEntry(selected); }
    function repair(): void {
        entriesUpdated();
        if (visible && hadFocus && (!selected || entries.indexOf(selected) < 0 || !selected.enabled || selected.isSeparator))
            focusInitial();
    }
    onEntriesChanged: repairLater.restart()
    Component.onCompleted: { opener = menuComponent.createObject(root, { handle: handle }); }
    Timer { id: repairLater; interval: 0; onTriggered: root.repair() }
    Component.onDestruction: { repairLater.stop(); if (opener) opener.destroy(); }
    UI.PanelText {
        width: parent.width
        visible: root.entries.length === 0
        text: qsTr("Brak dostępnych pozycji menu")
        color: Theme.textMuted
    }
    Repeater {
        id: buttons
        model: root.opener ? root.opener.entries : null
        UI.Button {
            id: button
            required property var modelData
            required property int index
            objectName: "trayMenuEntry-" + index
            width: root.width
            implicitHeight: modelData.isSeparator ? Metrics.space8 : Metrics.controlHeight
            enabled: modelData.enabled && !modelData.isSeparator
            text: modelData.text || qsTr("Bez nazwy")
            tooltip: text
            Accessible.role: modelData.buttonType === 1 ? Accessible.CheckBox
                : modelData.buttonType === 2 ? Accessible.RadioButton : Accessible.MenuItem
            Accessible.checkable: modelData.buttonType !== 0
            Accessible.checked: modelData.checkState === Qt.Checked
            onClicked: {
                if (modelData.hasChildren) root.descend(modelData);
                else root.activated(modelData);
            }
            onActiveFocusChanged: {
                if (activeFocus) {
                    root.selected = modelData;
                    root.hadFocus = true;
                    root.focusedOnce = true;
                    root.ensureVisible(button);
                }
            }
            onEnabledChanged: { if (!enabled && root.selected === modelData) repairLater.restart(); }
            Keys.onPressed: event => {
                if (event.modifiers !== Qt.NoModifier && event.modifiers !== Qt.KeypadModifier
                        && event.modifiers !== Qt.ShiftModifier) return;
                if (event.key === Qt.Key_J || event.key === Qt.Key_Down || (event.key === Qt.Key_Tab && event.modifiers === Qt.NoModifier))
                    root.moveSelection(index, 1);
                else if (event.key === Qt.Key_K || event.key === Qt.Key_Up || event.key === Qt.Key_Backtab || event.key === Qt.Key_Tab)
                    root.moveSelection(index, -1);
                else if (event.key === Qt.Key_H || event.key === Qt.Key_Left)
                    root.backRequested();
                else if (event.key === Qt.Key_L || event.key === Qt.Key_Right) {
                    if (modelData.hasChildren) root.descend(modelData);
                } else if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                    if (!event.isAutoRepeat) button.click();
                } else return;
                event.accepted = true;
            }
            contentItem: Row {
                spacing: Metrics.space8
                visible: !button.modelData.isSeparator
                Text {
                    width: 20; height: parent.height
                    text: button.modelData.buttonType === 0 ? "" : button.modelData.checkState === Qt.Checked
                        ? (button.modelData.buttonType === 2 ? "●" : "✓") : button.modelData.checkState === Qt.PartiallyChecked ? "−" : "○"
                    color: button.foreground; font: button.font; verticalAlignment: Text.AlignVCenter
                    Image {
                        anchors.fill: parent; sourceSize.width: 20; sourceSize.height: 20
                        visible: button.modelData.buttonType === 0 && source.toString().length > 0
                        source: button.modelData.buttonType === 0 ? button.modelData.icon : ""
                    }
                }
                Text {
                    width: Math.max(1, button.availableWidth - 40 - Metrics.space16); height: parent.height
                    text: button.text; textFormat: Text.PlainText
                    elide: Text.ElideRight; font: button.font; color: button.foreground
                    verticalAlignment: Text.AlignVCenter
                }
                Text {
                    width: 20; height: parent.height
                    text: button.modelData.hasChildren ? "›" : ""
                    font: button.font; color: button.foreground; verticalAlignment: Text.AlignVCenter
                }
            }
            background: Rectangle {
                color: button.modelData.isSeparator ? "transparent" : button.fillColor
                Rectangle {
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width; height: Metrics.borderWidth; color: Theme.border
                    visible: button.modelData.isSeparator
                }
                Rectangle {
                    anchors.fill: parent; anchors.margins: -Metrics.focusOffset
                    color: "transparent"; border.color: Theme.focus; border.width: Metrics.focusWidth
                    visible: button.activeFocus
                }
            }
        }
    }
}
