import QtQuick
import "../../core"
import "../../components" as UI

UI.NavigationButton {
    id: root
    required property var trayItem
    property bool showLabel: false
    signal primaryRequested()
    signal secondaryRequested()
    signal menuRequested()
    text: trayItem ? trayItem.title || trayItem.tooltipTitle || (trayItem["id"] || trayItem.objectName) || qsTr("Aplikacja w zasobniku") : ""
    tooltip: (trayItem ? trayItem.tooltipTitle || text : text)
        + (trayItem && trayItem.tooltipDescription ? "\n" + trayItem.tooltipDescription : "")
    padding: Metrics.space8
    implicitWidth: Metrics.trayButtonWidth
    implicitHeight: Metrics.barHeight
    onClicked: primaryRequested()
    // Right/middle clicks do not replace the standard Qt left-click handler.
    TapHandler { acceptedButtons: Qt.RightButton; onTapped: root.menuRequested() }
    TapHandler { acceptedButtons: Qt.MiddleButton; onTapped: root.secondaryRequested() }
    Keys.onMenuPressed: menuRequested()
    Shortcut { sequence: "Shift+F10"; enabled: root.activeFocus; onActivated: root.menuRequested() }
    Shortcut { sequence: "Shift+Return"; enabled: root.activeFocus; onActivated: root.secondaryRequested() }
    contentItem: Item {
        Image {
            id: icon
            anchors.left: parent.left; anchors.verticalCenter: parent.verticalCenter
            width: 20; height: 20
            sourceSize.width: 20; sourceSize.height: 20
            source: root.trayItem ? root.trayItem.icon : ""
            visible: status === Image.Ready
        }
        Text {
            objectName: "trayFallback"
            width: 20; height: parent.height
            text: root.text.slice(0, 1).toUpperCase() || "?"
            font: root.font; color: root.foreground
            horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
            visible: !icon.visible
        }
        Text {
            anchors.left: icon.right; anchors.leftMargin: Metrics.space8
            anchors.right: parent.right; height: parent.height
            visible: root.showLabel
            text: root.text; textFormat: Text.PlainText
            font: root.font; color: root.foreground
            verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight
        }
        Rectangle {
            width: 4; height: 4; anchors.right: parent.right; anchors.top: parent.top
            color: Theme.warning
            visible: root.trayItem !== null && root.trayItem.status === 2
        }
    }
}
