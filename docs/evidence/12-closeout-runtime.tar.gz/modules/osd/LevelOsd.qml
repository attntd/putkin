import QtQuick
import "../../core"
import "../../components" as UI

Rectangle {
    id: root
    required property real level
    required property string label
    required property url iconSource
    property color fillColor: Theme.accent
    implicitWidth: Metrics.osdWidth
    implicitHeight: Metrics.osdHeight
    color: Theme.backgroundStrong
    border.width: Metrics.borderWidth
    border.color: Theme.border
    Accessible.role: Accessible.Indicator
    Accessible.name: label

    Image {
        x: Metrics.space16; y: Metrics.space12
        width: Metrics.space24; height: Metrics.space24
        source: root.iconSource
    }
    UI.PanelText {
        objectName: "osdValue"
        x: Metrics.space16 + Metrics.space24 + Metrics.space12
        y: Metrics.space12
        width: parent.width - x - Metrics.space16
        height: Metrics.space24
        verticalAlignment: Text.AlignVCenter
        text: root.label
        wrapMode: Text.NoWrap
        elide: Text.ElideRight
    }
    Rectangle {
        x: Metrics.space16; y: parent.height - Metrics.space24
        width: parent.width - Metrics.space16 * 2
        height: Metrics.space4
        color: Theme.border
        Rectangle {
            objectName: "osdFill"
            width: parent.width * Math.max(0, Math.min(100, root.level)) / 100
            height: parent.height
            color: root.fillColor
        }
    }
}
