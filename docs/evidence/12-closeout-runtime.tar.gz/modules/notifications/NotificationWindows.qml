pragma ComponentBehavior: Bound

import QtQuick
import Quickshell

Variants {
    id: root
    required property var service
    required property var controller
    required property var panels
    model: service.screens
    delegate: QtObject {
        id: monitor
        required property ShellScreen modelData
        function sync(): void { loader.activeAsync = root.service.visibleOn(modelData.name).length > 0 && root.panels.screenName !== modelData.name; }
        readonly property LazyLoader loader: LazyLoader {
            id: loader
            NotificationWindow { screen: monitor.modelData; service: root.service; controller: root.controller }
        }
        readonly property Connections changes: Connections { target: root.service; function onChanged(): void { monitor.sync(); } }
        readonly property Connections panels: Connections { target: root.panels; function onSessionChanged(): void { monitor.sync(); } }
        Component.onCompleted: sync()
    }
}
