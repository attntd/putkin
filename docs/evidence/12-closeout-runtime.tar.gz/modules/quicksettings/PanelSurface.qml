pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls.Basic as Controls
import "../../core"
import "../settings"
import "../tray"
import "../power"

FocusScope {
    id: root
    required property var host
    property Item focusedControl: null
    readonly property var page: pageLoader.item
    readonly property alias viewport: flick
    implicitWidth: Math.min(Metrics.panelWidth, host.availableWidth)
    implicitHeight: (page ? page.implicitHeight : 0) + Metrics.space12 * 2
    enabled: host.interactive
    opacity: host.interactive ? 1 : 0
    Behavior on opacity { NumberAnimation { duration: Theme.reducedMotion ? 0 : Metrics.panelFade } }

    function focusInitial(): void {
        if (enabled && page)
            page.focusInitial();
    }
    function ensureVisible(item: Item): void {
        if (!item || !enabled)
            return;
        focusedControl = item;
        const y = item.mapToItem(flick.contentItem, 0, 0).y;
        const margin = Metrics.focusOffset + Metrics.focusWidth;
        if (y - margin < flick.contentY)
            flick.contentY = Math.max(0, y - margin);
        else if (y + item.height + margin > flick.contentY + flick.height)
            flick.contentY = Math.min(Math.max(0, flick.contentHeight - flick.height), y + item.height + margin - flick.height);
    }
    function revealFocus(): void {
        if (focusedControl && focusedControl.activeFocus)
            ensureVisible(focusedControl);
    }

    onEnabledChanged: {
        if (enabled)
            Qt.callLater(focusInitial);
        else
            focus = false;
    }
    Keys.priority: Keys.AfterItem
    Keys.onEscapePressed: { if (page) page.dismissOrCollapse(); }

    Rectangle {
        anchors.fill: parent
        color: Theme.backgroundStrong
        border.color: Theme.border
        border.width: Metrics.borderWidth
        Rectangle { width: parent.width; height: Metrics.borderWidth; color: Theme.accent }
    }
    Controls.ScrollView {
        anchors.fill: parent
        anchors.margins: Metrics.space12 - Metrics.focusOffset - Metrics.focusWidth
        contentWidth: availableWidth
        Controls.ScrollBar.horizontal.policy: Controls.ScrollBar.AlwaysOff
        Flickable {
            id: flick
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            contentWidth: width
            contentHeight: pageLoader.height + (Metrics.focusOffset + Metrics.focusWidth) * 2
            onHeightChanged: Qt.callLater(root.revealFocus)
            onContentHeightChanged: Qt.callLater(root.revealFocus)
            Loader {
                id: pageLoader
                x: Metrics.focusOffset + Metrics.focusWidth
                y: x
                width: Math.max(1, flick.width - x * 2)
                sourceComponent: root.host.surfaceId === "settings" ? settingsPage
                    : root.host.surfaceId === "power" ? powerPage
                    : root.host.surfaceId === "trayOverflow" || root.host.surfaceId === "trayMenu" ? trayPage : quickPage
                onLoaded: Qt.callLater(root.focusInitial)
            }
        }
    }
    Component { id: quickPage; QuickSettingsView { nightLight: root.host.nightLight; sessionService: root.host.sessionService; audio: root.host.audio; brightness: root.host.brightness; battery: root.host.battery; network: root.host.network; bluetooth: root.host.bluetooth; notifications: root.host.notifications; notificationController: root.host.notificationController; onHandoffRequested: root.host.coordinator.close(false); monitor: root.host.screen ? root.host.screen.name : "" } }
    Component { id: powerPage; PowerView { sessionService: root.host.sessionService } }
    Component { id: settingsPage; SettingsView { settings: root.host.coordinator.settings } }
    Component { id: trayPage; TrayView { host: root.host } }
    Connections {
        target: pageLoader.item
        function onRequested(surface: string): void { root.host.coordinator.open(surface, root.host.screen, null); }
        function onDismissed(): void { root.host.coordinator.close(true); }
        function onEnsureVisible(item: Item): void { root.ensureVisible(item); }
    }
}
