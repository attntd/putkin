import QtQuick
import "../../core"
import "../../components" as UI

Column {
    id: root
    required property var notifications
    required property var controller
    property Item previousControl: null
    property Item nextControl: null
    readonly property Item firstControl: dnd.enabled ? dnd : nextControl
    readonly property Item lastControl: enter.enabled ? enter : dnd.enabled ? dnd : previousControl
    spacing: Metrics.space8
    signal ensureVisible(Item item)
    UI.NavigationButton {
        id: dnd
        objectName: "notificationDnd"
        width: parent.width
        text: qsTr("Nie przeszkadzać · ") + (root.notifications.dnd ? qsTr("wł.") : qsTr("wył."))
        tooltip: qsTr("Wycisz zwykłe powiadomienia. Krytyczne pozostają widoczne.")
        checkable: true
        checked: root.notifications.dnd
        enabled: root.notifications.available
        upTarget: root.previousControl
        downTarget: enter.enabled ? enter : root.nextControl
        KeyNavigation.tab: downTarget
        KeyNavigation.backtab: upTarget
        onClicked: root.notifications.dnd = !root.notifications.dnd
        onEnsureVisible: item => root.ensureVisible(item)
    }
    UI.PanelText {
        objectName: "notificationStatus"
        width: parent.width
        text: root.notifications.statusText
        textFormat: Text.PlainText
        color: root.notifications.available ? Theme.textMuted : Theme.warning
    }
    UI.NavigationButton {
        id: enter
        objectName: "notificationFocus"
        width: parent.width
        text: qsTr("Przejdź do powiadomień")
        enabled: root.notifications.available && root.notifications.entries.some(entry => entry.shown)
        upTarget: dnd
        downTarget: root.nextControl
        KeyNavigation.tab: downTarget
        KeyNavigation.backtab: upTarget
        onClicked: root.controller.enter()
        onEnsureVisible: item => root.ensureVisible(item)
    }
}
