pragma ComponentBehavior: Bound

import QtQuick
import "../../core"
import "../../components" as UI

Column {
    id: root
    required property var audio
    required property string monitor
    required property Item nextControl
    required property Item previousControl
    property bool expanded: false
    property Item focusedControl: null
    readonly property Item firstControl: volume.enabled ? volume : outputs.enabled ? outputs : nextControl
    readonly property Item lastControl: expanded && devices.count ? devices.itemAt(devices.count - 1) : outputs.enabled ? outputs : previousControl
    signal ensureVisible(Item item)
    spacing: Metrics.space8

    function collapse(): bool {
        if (!expanded) return false;
        expanded = false;
        outputs.forceActiveFocus(Qt.TabFocusReason);
        return true;
    }
    function restoreVolume(): void { volume.value = Math.max(0, Math.min(100, audio.volume)); }
    function reveal(item: Item): void { focusedControl = item; ensureVisible(item); }
    function recoverUnavailableFocus(): void {
        const current = root.Window.window ? root.Window.window.activeFocusItem : null;
        if (current && current.enabled && current.visible && current.activeFocusOnTab) return;
        if (!audio.available && (focusedControl === volume || focusedControl === mute))
            (audio.outputs.length ? outputs : nextControl).forceActiveFocus(Qt.TabFocusReason);
    }
    onExpandedChanged: { if (expanded) Qt.callLater(() => root.ensureVisible(outputs)); }

    UI.PanelText {
        objectName: "audioStatus"
        width: parent.width
        text: qsTr("Dźwięk · ") + root.audio.statusText
        font.bold: true
    }
    UI.Slider {
        id: volume
        objectName: "audioVolume"
        width: parent.width
        accessibleName: qsTr("Głośność wyjścia")
        tooltip: root.audio.outputName + " · " + root.audio.statusText
        from: 0; to: 100; stepSize: 5
        enabled: root.audio.available
        value: Math.max(0, Math.min(100, root.audio.volume))
        // moved is user input only; backend updates must not write back.
        onMoved: {
            if (!root.audio.setVolume(value, root.monitor)) root.restoreVolume();
        }
        onActiveFocusChanged: { if (activeFocus) root.reveal(volume); }
        KeyNavigation.up: root.previousControl
        KeyNavigation.down: mute
        KeyNavigation.tab: mute
        KeyNavigation.backtab: root.previousControl
        Keys.onPressed: event => {
            if (event.modifiers !== Qt.NoModifier && event.modifiers !== Qt.KeypadModifier) return;
            if (event.key === Qt.Key_H || event.key === Qt.Key_L)
                root.audio.changeVolume(event.key === Qt.Key_H ? -stepSize : stepSize, root.monitor);
            else if (event.key === Qt.Key_J) mute.forceActiveFocus(Qt.TabFocusReason);
            else if (event.key === Qt.Key_K) root.previousControl.forceActiveFocus(Qt.TabFocusReason);
            else if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                if (!event.isAutoRepeat) root.audio.setVolume(value, root.monitor);
            } else return;
            event.accepted = true;
        }
    }
    UI.NavigationButton {
        id: mute
        objectName: "audioMute"
        width: parent.width
        enabled: root.audio.available
        text: root.audio.muted ? qsTr("Włącz dźwięk") : qsTr("Wycisz")
        highlighted: root.audio.muted
        upTarget: volume
        downTarget: outputs.enabled ? outputs : root.nextControl
        KeyNavigation.tab: downTarget
        KeyNavigation.backtab: volume
        onClicked: root.audio.toggleMute(root.monitor)
        onEnsureVisible: item => root.reveal(item)
    }
    UI.NavigationButton {
        id: outputs
        objectName: "audioOutputs"
        width: parent.width
        enabled: root.audio.outputs.length > 0
        text: (root.audio.outputName || qsTr("Wybierz wyjście")) + (root.expanded ? "  −" : "  +")
        tooltip: qsTr("Wyjście audio: ") + root.audio.outputName
        upTarget: mute.enabled ? mute : root.previousControl
        downTarget: root.expanded && devices.count ? devices.itemAt(0) : root.nextControl
        KeyNavigation.tab: downTarget
        KeyNavigation.backtab: upTarget
        onClicked: root.expanded = !root.expanded
        onEnsureVisible: item => root.reveal(item)
    }
    Column {
        width: parent.width
        visible: root.expanded
        spacing: Metrics.space4
        Repeater {
            id: devices
            model: root.audio.outputs
            UI.NavigationButton {
                id: device
                required property var modelData
                required property int index
                objectName: "audioOutput-" + modelData.name
                width: parent.width
                text: (root.audio.defaultOutput === modelData ? "✓ " : "  ") + root.audio.label(modelData)
                tooltip: root.audio.label(modelData)
                highlighted: root.audio.defaultOutput === modelData
                upTarget: index > 0 ? devices.itemAt(index - 1) : outputs
                downTarget: index + 1 < devices.count ? devices.itemAt(index + 1) : root.nextControl
                KeyNavigation.tab: downTarget
                KeyNavigation.backtab: upTarget
                onClicked: root.audio.selectOutput(modelData, root.monitor)
                onEnsureVisible: item => root.reveal(item)
            }
            onItemRemoved: (_index, item) => { if (item.activeFocus) root.nextControl.forceActiveFocus(Qt.TabFocusReason); }
        }
    }
    UI.PanelText { width: parent.width; visible: root.audio.busy; text: qsTr("Zmienianie…"); color: Theme.textMuted }
    UI.PanelText { objectName: "audioError"; width: parent.width; visible: text.length > 0; text: root.audio.lastError; color: Theme.error }
    Connections {
        target: root.audio
        function onVolumeChanged(): void { if (!root.audio.busy) root.restoreVolume(); }
        function onBusyChanged(): void { if (!root.audio.busy) root.restoreVolume(); }
        function onAvailableChanged(): void {
            if (!root.audio.available && (root.focusedControl === volume || root.focusedControl === mute))
                Qt.callLater(root.recoverUnavailableFocus);
        }
    }
}
