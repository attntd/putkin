import QtQuick
import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import "../../core"

// Same runtime factory metadata limitation as BarWindow (Quickshell 0.3.1).
// qmllint disable uncreatable-type
PanelWindow {
    // qmllint enable uncreatable-type
    id: root
    required property var host
    function dismissFromCompositor(): void {
        // A late event from a retiring window cannot close its replacement.
        if (host.window === root && host.interactive)
            host.coordinator.close(false);
    }
    screen: host.screen
    anchors { top: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    // Transparent padding also avoids the unresolved Margins value type in
    // the shipped 0.3.1 qmltypes. Only the actual panel accepts pointer input.
    implicitWidth: host.screen ? host.screen.width - host.surfaceX : 1
    implicitHeight: surface.y + surface.height
    color: "transparent"
    WlrLayershell.namespace: "putkin-panel"
    WlrLayershell.layer: WlrLayer.Overlay
    // The grab focuses this window and handles outside clicks. Exclusive
    // layer focus would route those clicks back here on Hyprland 0.56.2.
    WlrLayershell.keyboardFocus: host.interactive ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None
    mask: Region {
        x: surface.x
        y: surface.y
        width: root.host.interactive ? surface.width : 0
        height: root.host.interactive ? surface.height : 0
    }
    PanelSurface {
        id: surface
        host: root.host
        y: root.host.surfaceY(height)
        width: Math.min(Metrics.panelWidth, root.host.availableWidth)
        height: Math.min(implicitHeight, root.host.availableHeight)
    }
    HyprlandFocusGrab {
        windows: [root]
        active: root.host.interactive && root.visible
        onCleared: root.dismissFromCompositor()
    }
    onClosed: dismissFromCompositor()
}
