pragma ComponentBehavior: Bound

import QtQuick
import "../../core"
import "../../components" as UI

Column {
    id: root
    required property var bluetooth
    required property Item previousControl
    required property Item nextControl
    property bool expanded: false
    property Item lastFocused: null
    property int navigationRevision: 0
    readonly property Item firstControl: radio.enabled ? radio : expand
    readonly property Item lastControl: expanded ? manager : expand
    signal ensureVisible(Item item)
    signal handoffRequested()
    spacing: Metrics.space8

    function reveal(item: Item): void { lastFocused = item; ensureVisible(item); }
    function rowAt(repeater: var, index: int): Item {
        return navigationRevision >= 0 && repeater ? repeater.itemAt(index) : null;
    }
    function firstDevice(): Item { return devices.count && bluetooth.radioEnabled ? rowAt(devices, 0) : manager; }
    function lastDevice(): Item { return devices.count && bluetooth.radioEnabled ? rowAt(devices, devices.count - 1) : lastAdapter(); }
    function lastAdapter(): Item { return adapters.count > 1 ? rowAt(adapters, adapters.count - 1) : expand; }
    function collapse(): bool {
        if (!expanded) return false;
        expanded = false;
        expand.forceActiveFocus(Qt.TabFocusReason);
        return true;
    }
    UI.PanelText {
        objectName: "bluetoothStatus"
        width: parent.width
        textFormat: Text.PlainText
        text: root.bluetooth.statusText
        color: Theme.textMuted
    }
    Row {
        width: parent.width
        spacing: Metrics.space8
        UI.NavigationButton {
            id: radio
            objectName: "bluetoothRadio"
            width: (parent.width - parent.spacing) / 2
            text: root.bluetooth.busy && root.bluetooth.pending.kind === "radio" ? qsTr("Zmienianie…")
                : root.bluetooth.radioEnabled ? qsTr("Wyłącz Bluetooth") : qsTr("Włącz Bluetooth")
            highlighted: root.bluetooth.radioEnabled
            enabled: root.bluetooth.canRequest && !root.bluetooth.blocked
            rightTarget: expand
            upTarget: root.previousControl
            downTarget: expand.downTarget
            KeyNavigation.tab: expand
            KeyNavigation.backtab: root.previousControl
            onClicked: root.bluetooth.setEnabled(!root.bluetooth.radioEnabled)
            onEnsureVisible: item => root.reveal(item)
        }
        UI.NavigationButton {
            id: expand
            objectName: "bluetoothExpand"
            width: radio.width
            text: qsTr("Urządzenia") + (root.expanded ? "  −" : "  +")
            tooltip: qsTr("Sparowane urządzenia Bluetooth")
            leftTarget: radio.enabled ? radio : null
            upTarget: root.previousControl
            downTarget: root.expanded ? adapters.count > 1 ? root.rowAt(adapters, 0) : root.firstDevice() : root.nextControl
            KeyNavigation.tab: downTarget
            KeyNavigation.backtab: radio.enabled ? radio : root.previousControl
            onClicked: root.expanded = !root.expanded
            onEnsureVisible: item => root.reveal(item)
        }
    }
    UI.PanelText {
        objectName: "bluetoothPending"
        width: parent.width
        textFormat: Text.PlainText
        text: root.bluetooth.pendingText
        visible: text.length > 0
        color: Theme.textMuted
    }
    Column {
        width: parent.width
        visible: root.expanded
        spacing: Metrics.space8
        UI.PanelText {
            width: parent.width
            textFormat: Text.PlainText
            text: root.bluetooth.adapter ? qsTr("Adapter · ") + root.bluetooth.adapterLabel(root.bluetooth.adapter) : ""
            visible: text.length > 0
            color: Theme.textMuted
        }
        Column {
            width: parent.width
            visible: adapters.count > 1
            spacing: Metrics.space4
            Repeater {
                id: adapters
                model: root.bluetooth.adapters
                UI.NavigationButton {
                    id: adapterRow
                    required property var modelData
                    required property int index
                    objectName: "bluetoothAdapter-" + modelData.adapterId
                    width: root.width
                    text: (root.bluetooth.adapter === modelData ? "✓ " : "") + root.bluetooth.adapterLabel(modelData)
                    highlighted: root.bluetooth.adapter === modelData
                    upTarget: index > 0 ? root.rowAt(adapters, index - 1) : expand
                    downTarget: index + 1 < adapters.count ? root.rowAt(adapters, index + 1) : root.firstDevice()
                    KeyNavigation.tab: downTarget
                    KeyNavigation.backtab: upTarget
                    onClicked: root.bluetooth.selectAdapter(modelData)
                    onEnsureVisible: item => root.reveal(item)
                    contentItem: Text {
                        text: adapterRow.text
                        textFormat: Text.PlainText
                        font: adapterRow.font
                        color: adapterRow.foreground
                        elide: Text.ElideRight
                        verticalAlignment: Text.AlignVCenter
                    }
                }
                onItemAdded: root.navigationRevision++
                onItemRemoved: { root.navigationRevision++; recover.restart(); }
            }
        }
        Repeater {
            id: devices
            model: root.bluetooth.deviceModel
            UI.NavigationButton {
                id: entry
                required property var device
                required property int index
                objectName: "bluetoothDevice-" + index
                width: root.width
                implicitHeight: Metrics.controlHeight + Metrics.space16 + (batteryLine.visible ? Metrics.space16 : 0)
                enabled: root.bluetooth.radioEnabled && !!device && !!device.paired && !device.blocked
                highlighted: !!device && !!device.connected && root.bluetooth.radioEnabled
                text: root.bluetooth.label(device)
                tooltip: text + " · " + (device ? device.address || "" : "") + " · " + root.bluetooth.deviceStatus(device)
                    + (batteryLine.visible ? " · " + batteryLine.text : "")
                Accessible.description: tooltip
                upTarget: index > 0 ? root.rowAt(devices, index - 1) : root.lastAdapter()
                downTarget: index + 1 < devices.count ? root.rowAt(devices, index + 1) : manager
                KeyNavigation.tab: downTarget
                KeyNavigation.backtab: upTarget
                onClicked: root.bluetooth.activate(device)
                onEnsureVisible: item => root.reveal(item)
                contentItem: Column {
                    Text {
                        width: entry.availableWidth
                        text: entry.text
                        textFormat: Text.PlainText
                        font: entry.font
                        color: entry.foreground
                        elide: Text.ElideRight
                    }
                    Text {
                        width: entry.availableWidth
                        text: root.bluetooth.deviceStatus(entry.device)
                        textFormat: Text.PlainText
                        font.family: Theme.fontFamily
                        font.pixelSize: Metrics.smallFontSize
                        color: entry.foreground
                        elide: Text.ElideRight
                    }
                    Text {
                        id: batteryLine
                        width: entry.availableWidth
                        text: root.bluetooth.batteryText(entry.device)
                        visible: text.length > 0
                        textFormat: Text.PlainText
                        font.family: Theme.fontFamily
                        font.pixelSize: Metrics.smallFontSize
                        color: entry.foreground
                        elide: Text.ElideRight
                    }
                }
            }
            onItemAdded: root.navigationRevision++
            onItemRemoved: (_index, item) => {
                root.navigationRevision++;
                if (item === root.lastFocused) recover.restart();
            }
        }
        UI.PanelText {
            objectName: "bluetoothEmpty"
            width: parent.width
            visible: !!root.bluetooth.adapter && devices.count === 0
            text: qsTr("Brak sparowanych urządzeń na tym adapterze")
            color: Theme.textMuted
        }
        UI.NavigationButton {
            id: manager
            objectName: "bluetoothManager"
            width: parent.width
            text: root.bluetooth.backend.managerBusy ? qsTr("Otwieranie menedżera…") : qsTr("Sparuj nowe urządzenie…")
            tooltip: qsTr("Otwórz Blueman w osobnym oknie, aby sparować nowe urządzenie")
            upTarget: root.lastDevice()
            downTarget: root.nextControl
            KeyNavigation.tab: root.nextControl
            KeyNavigation.backtab: upTarget
            onClicked: root.bluetooth.openManager()
            onEnsureVisible: item => root.reveal(item)
        }
        UI.PanelText {
            width: parent.width
            text: qsTr("Parowanie otworzy Blueman w osobnym oknie.")
            color: Theme.textMuted
        }
        UI.PanelText {
            objectName: "bluetoothManagerError"
            width: parent.width
            textFormat: Text.PlainText
            text: root.bluetooth.backend.managerError
            visible: text.length > 0
            color: Theme.error
        }
    }
    UI.PanelText {
        objectName: "bluetoothError"
        width: parent.width
        textFormat: Text.PlainText
        text: root.bluetooth.lastError
        visible: text.length > 0
        color: Theme.error
    }
    Timer {
        id: recover
        interval: 0
        onTriggered: {
            if (!root.enabled || !root.visible) return;
            const current = root.Window.window ? root.Window.window.activeFocusItem : null;
            if (!current || !current.enabled || !current.visible || !current.activeFocusOnTab)
                expand.forceActiveFocus(Qt.TabFocusReason);
        }
    }
    Connections {
        target: root.bluetooth
        function onCanRequestChanged(): void { recover.restart(); }
        function onRadioEnabledChanged(): void { recover.restart(); }
    }
    Connections {
        target: root.bluetooth.backend
        function onManagerRequested(): void { root.handoffRequested(); }
    }
}
