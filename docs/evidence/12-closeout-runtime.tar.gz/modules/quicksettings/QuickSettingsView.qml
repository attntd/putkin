pragma ComponentBehavior: Bound

import QtQuick
import "../../core"
import "../../components" as UI
import "../settings"

Column {
    id: root
    property bool expanded: false
    property var audio: null
    property var brightness: null
    property var nightLight: null
    property var battery: null
    property var network: null
    property var bluetooth: null
    property var notifications: null
    property var sessionService: null
    property var notificationController: null
    property string monitor: ""
    readonly property AudioSection audioSection: audioLoader.item as AudioSection
    readonly property BrightnessSection brightnessSection: brightnessLoader.item as BrightnessSection
    readonly property NetworkSection networkSection: networkLoader.item as NetworkSection
    readonly property BluetoothSection bluetoothSection: bluetoothLoader.item as BluetoothSection
    readonly property NotificationSection notificationSection: notificationLoader.item as NotificationSection
    readonly property NightLightSection nightLightSection: nightLightLoader.item as NightLightSection
    readonly property Item afterNetwork: bluetoothSection ? bluetoothSection.firstControl : afterBluetooth
    readonly property Item beforeAudio: bluetoothSection ? bluetoothSection.lastControl : networkSection ? networkSection.lastControl : close
    readonly property Item afterBluetooth: audioSection ? audioSection.firstControl : afterAudio
    readonly property Item afterAudio: brightnessSection ? brightnessSection.firstControl : afterBrightness
    readonly property Item afterBrightness: nightLightSection ? nightLightSection.firstControl : afterNightLight
    readonly property Item afterNightLight: notificationSection ? notificationSection.firstControl : theme
    readonly property Item beforeNightLight: brightnessSection ? brightnessSection.lastControl : audioSection ? audioSection.lastControl : beforeAudio
    readonly property Item beforeNotifications: nightLightSection ? nightLightSection.lastControl : beforeNightLight
    spacing: Metrics.space16
    signal requested(string surface)
    signal dismissed()
    signal handoffRequested()
    signal ensureVisible(Item item)
    function focusInitial(): void { (networkSection ? networkSection.firstControl : afterNetwork).forceActiveFocus(Qt.TabFocusReason); }
    function dismissOrCollapse(): void {
        if (networkSection && networkSection.collapse()) return;
        if (bluetoothSection && bluetoothSection.collapse()) return;
        if (audioSection && audioSection.collapse()) return;
        if (brightnessSection && brightnessSection.collapse()) return;
        if (expanded) {
            expanded = false;
            focusInitial();
        } else
            dismissed();
    }

    UI.PanelText { width: parent.width; text: qsTr("Szybkie ustawienia"); font.bold: true }
    Loader {
        id: networkLoader
        width: parent.width
        active: root.network !== null
        visible: active
        sourceComponent: NetworkSection {
            network: root.network
            previousControl: close
            nextControl: root.afterNetwork
            onEnsureVisible: item => root.ensureVisible(item)
        }
    }
    Loader {
        id: bluetoothLoader
        width: parent.width
        active: root.bluetooth !== null
        visible: active
        sourceComponent: BluetoothSection {
            bluetooth: root.bluetooth
            previousControl: root.networkSection ? root.networkSection.lastControl : close
            nextControl: root.afterBluetooth
            onEnsureVisible: item => root.ensureVisible(item)
            onHandoffRequested: root.handoffRequested()
        }
    }
    UI.PanelText {
        objectName: "batteryStatus"
        width: parent.width
        visible: root.battery !== null
        text: root.battery ? qsTr("Bateria komputera · ") + root.battery.statusText : ""
        color: root.battery && root.battery.warningLevel === 2 ? Theme.error
            : root.battery && root.battery.warningLevel === 1 ? Theme.warning : Theme.textMuted
    }
    Loader {
        id: audioLoader
        width: parent.width
        active: root.audio !== null
        visible: active
        sourceComponent: AudioSection {
            audio: root.audio
            monitor: root.monitor
            nextControl: root.afterAudio
            previousControl: root.beforeAudio
            onEnsureVisible: item => root.ensureVisible(item)
        }
    }
    Loader {
        id: brightnessLoader
        width: parent.width
        active: root.brightness !== null
        visible: active
        sourceComponent: BrightnessSection {
            brightness: root.brightness
            monitor: root.monitor
            previousControl: root.audioSection ? root.audioSection.lastControl : root.beforeAudio
            nextControl: root.afterBrightness
            onEnsureVisible: item => root.ensureVisible(item)
        }
    }
    Loader {
        id: nightLightLoader
        width: parent.width
        active: root.nightLight !== null
        visible: active
        sourceComponent: NightLightSection {
            nightLight: root.nightLight
            previousControl: root.beforeNightLight
            nextControl: root.afterNightLight
            onEnsureVisible: item => root.ensureVisible(item)
        }
    }
    Loader {
        id: notificationLoader
        width: parent.width
        active: root.notifications !== null
        visible: active
        sourceComponent: NotificationSection {
            notifications: root.notifications
            controller: root.notificationController
            previousControl: root.beforeNotifications
            nextControl: theme
            onEnsureVisible: item => root.ensureVisible(item)
        }
    }
    UI.NavigationButton {
        id: theme
        objectName: "themeButton"
        width: parent.width
        text: qsTr("Motyw · Mocha") + (root.expanded ? "  −" : "  +")
        tooltip: root.expanded ? qsTr("Zwiń opis motywu") : qsTr("Rozwiń opis motywu")
        downTarget: root.sessionService ? lock.enabled ? lock : power : settings.enabled ? settings : close
        upTarget: root.notificationSection ? root.notificationSection.lastControl : root.beforeNotifications
        KeyNavigation.tab: downTarget
        KeyNavigation.backtab: upTarget
        onClicked: root.expanded = !root.expanded
        onEnsureVisible: item => root.ensureVisible(item)
    }
    ThemeDetails { width: parent.width; visible: root.expanded }
    Row {
        visible: root.sessionService !== null
        width: parent.width
        spacing: Metrics.space12
        UI.NavigationButton {
            id: lock
            objectName: "lockButton"
            width: (parent.width - parent.spacing) / 2
            text: qsTr("Blokada")
            enabled: root.sessionService !== null && !root.sessionService.busy && root.sessionService.capability("lock").available
            upTarget: theme
            rightTarget: power
            downTarget: settings
            KeyNavigation.tab: power
            KeyNavigation.backtab: theme
            onClicked: root.sessionService.request("lock")
            onEnsureVisible: item => root.ensureVisible(item)
        }
        UI.NavigationButton {
            id: power
            objectName: "powerButton"
            width: lock.width
            text: qsTr("Zasilanie")
            upTarget: theme
            leftTarget: lock
            downTarget: close
            KeyNavigation.tab: settings
            KeyNavigation.backtab: lock.enabled ? lock : theme
            onClicked: root.requested("power")
            onEnsureVisible: item => root.ensureVisible(item)
        }
    }
    UI.PanelText {
        objectName: "sessionStatus"
        width: parent.width
        visible: root.sessionService !== null && text.length > 0
        text: !root.sessionService ? "" : root.sessionService.busy ? (root.sessionService.phase === "locking" ? qsTr("Oczekiwanie na potwierdzenie blokady…") : qsTr("Oczekiwanie na wynik operacji…"))
            : root.sessionService.lastError || root.sessionService.resultText || root.sessionService.capability("lock").reason
        color: root.sessionService && root.sessionService.lastError ? Theme.error : Theme.textMuted
    }
    Row {
        width: parent.width
        spacing: Metrics.space12
        UI.NavigationButton {
            id: settings
            objectName: "settingsButton"
            width: (parent.width - parent.spacing) / 2
            text: qsTr("Ustawienia")
            upTarget: root.sessionService ? lock.enabled ? lock : power : theme
            rightTarget: close
            KeyNavigation.tab: close
            KeyNavigation.backtab: root.sessionService ? power : theme
            onClicked: root.requested("settings")
            onEnsureVisible: item => root.ensureVisible(item)
        }
        UI.NavigationButton {
            id: close
            objectName: "closeButton"
            width: settings.width
            text: qsTr("Zamknij")
            leftTarget: settings
            upTarget: root.sessionService ? power : theme
            downTarget: root.networkSection ? root.networkSection.firstControl : root.afterNetwork
            KeyNavigation.tab: downTarget
            KeyNavigation.backtab: settings
            onClicked: root.dismissed()
            onEnsureVisible: item => root.ensureVisible(item)
        }
    }
}
