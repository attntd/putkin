import QtQuick
import "../../core"
import "../../components" as UI

Column {
    id: root
    required property var brightness
    required property string monitor
    required property Item previousControl
    required property Item nextControl
    property bool expanded: false
    property bool hadSliderFocus: false
    readonly property Item firstControl: brightness.available ? slider : details
    readonly property Item lastControl: expanded ? refresh : details
    signal ensureVisible(Item item)
    spacing: Metrics.space8

    function restore(): void { slider.value = Math.max(1, Math.min(100, brightness.requestedPercent)); }
    function collapse(): bool {
        if (!expanded) return false;
        expanded = false;
        details.forceActiveFocus(Qt.TabFocusReason);
        return true;
    }
    function recoverFocus(): void {
        const current = root.Window.window ? root.Window.window.activeFocusItem : null;
        if (hadSliderFocus && (!current || !current.enabled || !current.visible || !current.activeFocusOnTab))
            details.forceActiveFocus(Qt.TabFocusReason);
    }
    UI.PanelText {
        objectName: "brightnessStatus"
        width: parent.width
        visible: root.brightness.available
        text: qsTr("Jasność · ") + root.brightness.statusText
        font.bold: true
    }
    UI.Slider {
        id: slider
        objectName: "brightnessSlider"
        width: parent.width
        visible: root.brightness.available
        enabled: visible
        accessibleName: qsTr("Jasność podświetlenia")
        tooltip: root.brightness.device + " · " + root.brightness.statusText
        fillColor: Theme.accentSecondary
        from: 1; to: 100
        stepSize: root.brightness.available ? Math.max(5, 100 / root.brightness.sample.maximum) : 5
        value: Math.max(1, Math.min(100, root.brightness.requestedPercent))
        onMoved: { if (!root.brightness.setPercent(value, root.monitor)) root.restore(); }
        onPressedChanged: { if (!pressed && !root.brightness.busy) root.restore(); }
        onActiveFocusChanged: { if (activeFocus) { root.hadSliderFocus = true; root.ensureVisible(slider); } }
        KeyNavigation.up: root.previousControl
        KeyNavigation.down: details
        KeyNavigation.tab: details
        KeyNavigation.backtab: root.previousControl
        Keys.onPressed: event => {
            if (event.modifiers !== Qt.NoModifier && event.modifiers !== Qt.KeypadModifier) return;
            if (event.key === Qt.Key_H || event.key === Qt.Key_L)
                root.brightness.change(event.key === Qt.Key_H ? -stepSize : stepSize, root.monitor);
            else if (event.key === Qt.Key_J) details.forceActiveFocus(Qt.TabFocusReason);
            else if (event.key === Qt.Key_K) root.previousControl.forceActiveFocus(Qt.TabFocusReason);
            else if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                if (!event.isAutoRepeat) root.brightness.setPercent(value, root.monitor);
            } else return;
            event.accepted = true;
        }
    }
    UI.PanelText {
        width: parent.width
        visible: root.brightness.busy
        text: root.brightness.pending ? qsTr("Zmienianie na %1%…").arg(Math.round(root.brightness.requestedPercent)) : qsTr("Odczytywanie…")
        color: Theme.textMuted
    }
    UI.PanelText { objectName: "brightnessError"; width: parent.width; visible: text.length > 0; text: root.brightness.lastError; color: Theme.error }
    UI.NavigationButton {
        id: details
        objectName: "brightnessDetails"
        width: parent.width
        text: (root.brightness.available ? qsTr("Podświetlenie · szczegóły") : qsTr("Jasność niedostępna · szczegóły")) + (root.expanded ? "  −" : "  +")
        upTarget: root.brightness.available ? slider : root.previousControl
        downTarget: root.expanded ? refresh : root.nextControl
        KeyNavigation.tab: downTarget
        KeyNavigation.backtab: upTarget
        onClicked: root.expanded = !root.expanded
        onEnsureVisible: item => { root.hadSliderFocus = false; root.ensureVisible(item); }
    }
    UI.PanelText { width: parent.width; visible: root.expanded; text: root.brightness.diagnostic; color: Theme.textMuted }
    UI.NavigationButton {
        id: refresh
        objectName: "brightnessRefresh"
        width: parent.width
        visible: root.expanded
        text: qsTr("Odśwież podświetlenie")
        upTarget: details
        downTarget: root.nextControl
        KeyNavigation.tab: downTarget
        KeyNavigation.backtab: details
        onClicked: root.brightness.refresh()
        onEnsureVisible: item => { root.hadSliderFocus = false; root.ensureVisible(item); }
    }
    Connections {
        target: root.brightness
        function onRequestedPercentChanged(): void { if (!slider.pressed) root.restore(); }
        function onBusyChanged(): void { if (!root.brightness.busy && !slider.pressed) root.restore(); }
        function onAvailableChanged(): void { if (!root.brightness.available) Qt.callLater(root.recoverFocus); }
    }
}
