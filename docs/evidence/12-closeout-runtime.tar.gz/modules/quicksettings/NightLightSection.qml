import QtQuick
import "../../core"
import "../../components" as UI

Column {
    id: root
    required property var nightLight
    required property Item previousControl
    required property Item nextControl
    readonly property Item firstControl: toggle.enabled ? toggle : refresh
    readonly property Item lastControl: refresh
    property bool hadControlFocus: false
    spacing: Metrics.space8
    signal ensureVisible(Item item)

    function restore(): void { slider.value = Math.max(1000, Math.min(6500, nightLight.temperature || nightLight.preferredTemperature)); }
    function recoverFocus(): void {
        if (hadControlFocus && !nightLight.available) refresh.forceActiveFocus(Qt.TabFocusReason);
    }
    UI.PanelText {
        width: parent.width
        text: qsTr("Światło nocne · ") + root.nightLight.statusText
        font.bold: true
    }
    UI.NavigationButton {
        id: toggle
        objectName: "nightLightToggle"
        width: parent.width
        visible: root.nightLight.available
        enabled: visible && !root.nightLight.busy
        text: root.nightLight.enabled ? qsTr("Wyłącz światło nocne") : qsTr("Włącz światło nocne")
        checked: root.nightLight.enabled
        upTarget: root.previousControl
        downTarget: slider.enabled ? slider : refresh
        KeyNavigation.tab: downTarget
        KeyNavigation.backtab: upTarget
        onClicked: root.nightLight.setEnabled(!root.nightLight.enabled)
        onEnsureVisible: item => { root.hadControlFocus = true; root.ensureVisible(item); }
    }
    UI.Slider {
        id: slider
        objectName: "nightLightTemperature"
        width: parent.width
        visible: root.nightLight.available && root.nightLight.enabled
        enabled: visible && !root.nightLight.busy
        accessibleName: qsTr("Temperatura światła nocnego")
        tooltip: qsTr("%1 K · niżej oznacza cieplejszy obraz").arg(Math.round(value))
        from: 1000; to: 6500; stepSize: 100
        live: false
        value: Math.max(1000, Math.min(6500, root.nightLight.temperature || root.nightLight.preferredTemperature))
        onMoved: { if (!root.nightLight.setTemperature(value)) root.restore(); }
        onActiveFocusChanged: { if (activeFocus) { root.hadControlFocus = true; root.ensureVisible(slider); } }
        KeyNavigation.up: toggle.enabled ? toggle : refresh
        KeyNavigation.down: refresh
        KeyNavigation.tab: refresh
        KeyNavigation.backtab: toggle.enabled ? toggle : refresh
        Keys.onPressed: event => {
            if (event.modifiers !== Qt.NoModifier && event.modifiers !== Qt.KeypadModifier) return;
            if (event.key === Qt.Key_H || event.key === Qt.Key_L) {
                const next = Math.max(from, Math.min(to, value + (event.key === Qt.Key_H ? -stepSize : stepSize)));
                root.nightLight.setTemperature(next);
            } else if (event.key === Qt.Key_J) refresh.forceActiveFocus(Qt.TabFocusReason);
            else if (event.key === Qt.Key_K) root.firstControl.forceActiveFocus(Qt.TabFocusReason);
            else if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                if (!event.isAutoRepeat) root.nightLight.setTemperature(value);
            } else return;
            event.accepted = true;
        }
    }
    UI.PanelText { width: parent.width; visible: root.nightLight.busy; text: qsTr("Oczekiwanie na potwierdzenie…"); color: Theme.textMuted }
    UI.PanelText { objectName: "nightLightError"; width: parent.width; visible: text.length > 0; text: root.nightLight.lastError; color: Theme.textMuted }
    UI.NavigationButton {
        id: refresh
        objectName: "nightLightRefresh"
        width: parent.width
        text: qsTr("Odśwież światło nocne")
        upTarget: slider.enabled ? slider : toggle.enabled ? toggle : root.previousControl
        downTarget: root.nextControl
        KeyNavigation.tab: downTarget
        KeyNavigation.backtab: upTarget
        onClicked: root.nightLight.refresh()
        onEnsureVisible: item => { root.hadControlFocus = false; root.ensureVisible(item); }
    }
    Connections {
        target: root.nightLight
        function onRefreshed(): void { root.restore(); Qt.callLater(root.recoverFocus); }
    }
}
