pragma ComponentBehavior: Bound

import QtQuick
import "../../core"
import "../../components" as UI

Column {
    id: root
    required property var sessionService
    property string confirmation: ""
    property var controls: []
    readonly property var actions: [
        { id: "logout", title: qsTr("Wyloguj"), icon: "logout" },
        { id: "reboot", title: qsTr("Uruchom ponownie"), icon: "restart" },
        { id: "poweroff", title: qsTr("Wyłącz"), icon: "power" },
        { id: "suspend", title: qsTr("Uśpij"), icon: "sleep" }
    ]
    spacing: Metrics.space12
    signal dismissed()
    signal requested(string surface)
    signal ensureVisible(Item item)
    function title(action: string): string { const value = actions.find(item => item.id === action); return value ? value.title : ""; }
    function button(index: int): Item { return controls[index] || null; }
    function rebuildNavigation(): void {
        const items = [];
        for (let i = 0; i < choices.count; ++i) {
            const item = choices.itemAt(i) as ActionRow;
            items.push(item ? item.control : null);
        }
        controls = items;
    }
    function focusInitial(): void {
        if (confirmation) cancel.forceActiveFocus(Qt.TabFocusReason);
        else {
            for (let i = 0; i < actions.length; ++i) {
                const item = button(i);
                if (item && item.enabled) { item.forceActiveFocus(Qt.TabFocusReason); return; }
            }
            close.forceActiveFocus(Qt.TabFocusReason);
        }
    }
    function dismissOrCollapse(): void {
        if (confirmation) { confirmation = ""; Qt.callLater(focusInitial); }
        else dismissed();
    }
    function choose(action: string): void {
        if (sessionService.busy || !sessionService.capability(action).available) return;
        if (action === "suspend") { sessionService.request(action); close.forceActiveFocus(Qt.TabFocusReason); return; }
        confirmation = action;
        Qt.callLater(focusInitial);
    }
    onEnabledChanged: { if (!enabled) confirmation = ""; }

    UI.PanelText { width: parent.width; text: qsTr("Zasilanie"); font.bold: true }
    UI.PanelText {
        width: parent.width
        visible: root.confirmation.length > 0
        text: qsTr("%1? Niezapisana praca może zostać utracona.").arg(root.title(root.confirmation))
    }
    Repeater {
        id: choices
        model: root.actions
        delegate: ActionRow {}
        onItemAdded: root.rebuildNavigation()
        onItemRemoved: root.rebuildNavigation()
    }
    component ActionRow: Column {
            id: row
            required property var modelData
            required property int index
            readonly property alias control: action
            readonly property var capability: root.sessionService.capability(modelData.id)
            width: root.width
            spacing: Metrics.space4
            visible: !root.confirmation
            UI.NavigationButton {
                id: action
                objectName: "power-" + row.modelData.id
                width: parent.width
                text: row.modelData.title
                enabled: row.capability.available && !root.sessionService.busy
                tooltip: row.modelData.title + (row.capability.reason ? " · " + row.capability.reason : "")
                upTarget: row.index > 0 ? root.button(row.index - 1) : close
                downTarget: row.index < root.actions.length - 1 ? root.button(row.index + 1) : close
                KeyNavigation.tab: downTarget
                KeyNavigation.backtab: upTarget
                onClicked: root.choose(row.modelData.id)
                onEnsureVisible: item => root.ensureVisible(item)
                Image {
                    anchors.left: parent.left
                    anchors.leftMargin: Metrics.space12
                    anchors.verticalCenter: parent.verticalCenter
                    width: 18; height: 18
                    source: "../../assets/icons/" + row.modelData.icon + ".svg"
                    opacity: action.enabled ? 1 : 0.45
                }
            }
            UI.PanelText {
                width: parent.width
                visible: text.length > 0
                text: row.capability.reason
                color: row.capability.available ? Theme.textMuted : Theme.warning
                font.pixelSize: Metrics.smallFontSize
            }
    }
    Row {
        width: parent.width
        spacing: Metrics.space12
        visible: root.confirmation.length > 0
        UI.NavigationButton {
            id: cancel
            objectName: "powerCancel"
            width: (parent.width - parent.spacing) / 2
            text: qsTr("Anuluj")
            rightTarget: confirm
            downTarget: close
            KeyNavigation.tab: confirm.enabled ? confirm : close
            KeyNavigation.backtab: close
            onClicked: root.dismissOrCollapse()
            onEnsureVisible: item => root.ensureVisible(item)
        }
        UI.NavigationButton {
            id: confirm
            objectName: "powerConfirm"
            width: cancel.width
            text: root.title(root.confirmation)
            enabled: !!root.confirmation && !root.sessionService.busy && root.sessionService.capability(root.confirmation).available
            leftTarget: cancel
            downTarget: close
            KeyNavigation.tab: close
            KeyNavigation.backtab: cancel
            onClicked: {
                const action = root.confirmation;
                root.confirmation = "";
                root.sessionService.request(action);
                close.forceActiveFocus(Qt.TabFocusReason);
            }
            onEnsureVisible: item => root.ensureVisible(item)
        }
    }
    UI.PanelText {
        objectName: "powerResult"
        width: parent.width
        text: root.sessionService.busy ? (root.sessionService.phase === "locking" ? qsTr("Oczekiwanie na potwierdzenie blokady…") : qsTr("Oczekiwanie na wynik operacji…"))
            : root.sessionService.lastError || root.sessionService.resultText
        visible: text.length > 0
        color: root.sessionService.lastError ? Theme.error : Theme.textMuted
    }
    UI.NavigationButton {
        id: close
        objectName: "powerClose"
        width: parent.width
        text: qsTr("Zamknij")
        upTarget: root.confirmation ? cancel : root.button(3)
        downTarget: root.confirmation ? cancel : root.button(0)
        KeyNavigation.tab: downTarget
        KeyNavigation.backtab: upTarget
        onClicked: root.dismissed()
        onEnsureVisible: item => root.ensureVisible(item)
    }
}
