import QtQuick
import "../../components" as UI
import "../../core"

UI.Button {
    id: root
    required property int workspaceId
    required property bool occupied
    required property bool urgent
    required property string visibleOn
    required property string screenName
    readonly property bool activeHere: visibleOn.length > 0 && visibleOn === screenName
    readonly property bool activeElsewhere: visibleOn.length > 0 && visibleOn !== screenName

    implicitWidth: Metrics.workspaceWidth
    implicitHeight: Metrics.barHeight
    padding: Metrics.space4
    text: (activeHere ? "▸" : activeElsewhere ? "○" : "") + workspaceId + (urgent ? "!" : occupied ? "·" : "")
    tooltip: qsTr("Workspace %1").arg(workspaceId)
        + (activeHere ? qsTr(" — aktywny tutaj") : activeElsewhere ? qsTr(" — widoczny na %1").arg(visibleOn) : "")
        + (occupied ? qsTr(", zajęty") : qsTr(", pusty")) + (urgent ? qsTr(", pilny") : "")
    Accessible.name: tooltip
    foreground: !enabled ? Theme.textDisabled : activeHere ? Theme.accentText : urgent ? Theme.error : Theme.text
    font.bold: activeHere || urgent
    background: Rectangle {
        color: root.activeHere ? Theme.accent : root.down ? Theme.surfaceHover : root.hovered ? Theme.surface : Theme.background
        border.width: root.activeHere ? Metrics.borderWidth : 0
        border.color: Theme.accentBorder
        Rectangle {
            objectName: "focusIndicator"
            anchors.fill: parent
            anchors.margins: Metrics.focusWidth
            color: "transparent"
            border.width: Metrics.focusWidth
            border.color: root.activeHere ? Theme.accentText : Theme.focus
            visible: root.activeFocus
        }
    }
}
