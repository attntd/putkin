pragma ComponentBehavior: Bound

import QtQuick
import "../../core"
import "../../components" as UI
import "../tray"

Rectangle {
    id: root
    required property var service
    required property string screenName
    required property date date
    property var audio: null
    property var battery: null
    property var tray: null
    property var network: null
    readonly property alias networkButton: networkButton
    readonly property alias trayStrip: trayStrip
    readonly property alias batteryButton: batteryButton
    property bool navigating: false
    property bool panelActive: false
    property bool windowedTooltips: false
    readonly property alias workspaces: strip
    readonly property alias clock: clock
    readonly property alias quickSettingsButton: quickSettings
    readonly property alias audioButton: audioButton
    signal trayMenuRequested(var item, Item invoker)
    signal trayOverflowRequested(Item invoker)
    signal trayActivationRequested(var item, bool secondary)
    signal dismissed()
    signal quickSettingsRequested(Item invoker)

    function focusQuickSettings(): void {
        quickSettings.forceActiveFocus(Qt.TabFocusReason);
    }

    function enter(): void {
        if (strip.available)
            strip.enter();
        else
            focusQuickSettings();
    }

    implicitHeight: Metrics.barHeight
    color: Theme.background

    WorkspaceStrip {
        id: strip
        width: Math.min(Metrics.workspaceMaxWidth, Math.max(Metrics.workspaceWidth,
            root.width - clock.width - Metrics.barStatusReserve - audioButton.width - batteryButton.width - networkButton.width - trayStrip.width - Metrics.space16))
        height: parent.height
        service: root.service
        screenName: root.screenName
        navigating: root.navigating
        nextControl: trayStrip.width > 0 ? trayStrip.firstControl : networkButton.visible ? networkButton : audioButton.visible ? audioButton : batteryButton.visible ? batteryButton : quickSettings
        windowedTooltips: root.windowedTooltips
        visible: available
        onDismissed: root.dismissed()
    }
    Text {
        objectName: "unavailable"
        visible: !strip.available
        anchors.left: parent.left
        anchors.leftMargin: Metrics.space8
        height: parent.height
        width: strip.width
        text: qsTr("Workspace — niedostępne")
        elide: Text.ElideRight
        verticalAlignment: Text.AlignVCenter
        font.family: Theme.fontFamily
        font.pixelSize: Metrics.fontSize
        color: Theme.textMuted
    }
    Text {
        objectName: "actionError"
        visible: strip.available && root.service.lastError.length > 0
        anchors.left: strip.right
        anchors.right: trayStrip.left
        anchors.margins: Metrics.space8
        height: parent.height
        text: root.service.lastError
        elide: Text.ElideRight
        verticalAlignment: Text.AlignVCenter
        font.family: Theme.fontFamily
        font.pixelSize: Metrics.smallFontSize
        color: Theme.error
    }
    Clock {
        id: clock
        anchors.right: parent.right
        height: parent.height
        date: root.date
        windowedTooltip: root.windowedTooltips
        dateStyle: root.width >= 1500 ? 2 : root.width >= 600 ? 1 : 0
    }
    TrayStrip {
        id: trayStrip
        anchors.right: networkButton.left
        tray: root.tray
        capacity: root.width >= 1000 ? Metrics.trayVisibleLimit : root.width >= 600 ? 2 : 0
        previousControl: strip.available ? strip.list.currentItem : quickSettings
        nextControl: networkButton.visible ? networkButton : audioButton.visible ? audioButton : batteryButton.visible ? batteryButton : quickSettings
        windowedTooltips: root.windowedTooltips
        onMenuRequested: (item, invoker) => root.trayMenuRequested(item, invoker)
        onOverflowRequested: invoker => root.trayOverflowRequested(invoker)
        onActivationRequested: (item, secondary) => root.trayActivationRequested(item, secondary)
        onDismissed: root.dismissed()
    }
    BatteryButton {
        id: batteryButton
        objectName: "barBattery"
        anchors.right: quickSettings.left
        battery: root.battery
        visible: root.battery !== null && root.battery.present
        compact: root.width < 600
        width: visible ? (compact ? Metrics.barStatusReserve : 88) : 0
        windowedTooltip: root.windowedTooltips
        leftTarget: audioButton.visible ? audioButton : networkButton.visible ? networkButton : trayStrip.width > 0 ? trayStrip.lastControl : strip.available ? strip.list.currentItem : null
        rightTarget: quickSettings
        KeyNavigation.backtab: leftTarget
        KeyNavigation.tab: rightTarget
        onClicked: root.quickSettingsRequested(batteryButton)
        Keys.onEscapePressed: root.dismissed()
        onVisibleChanged: { if (!visible && activeFocus) quickSettings.forceActiveFocus(Qt.TabFocusReason); }
    }
    UI.NavigationButton {
        id: audioButton
        objectName: "barAudio"
        anchors.right: batteryButton.left
        visible: root.audio !== null && (root.width >= 480 || (!batteryButton.visible && trayStrip.width === 0))
        width: visible ? (root.width >= 600 ? 88 : Metrics.barStatusReserve) : 0
        height: parent.height
        padding: Metrics.space8
        text: root.audio ? qsTr("Dźwięk · ") + root.audio.statusText : ""
        tooltip: text + (root.audio && root.audio.outputName ? " · " + root.audio.outputName : "")
        windowedTooltip: root.windowedTooltips
        leftTarget: networkButton.visible ? networkButton : trayStrip.width > 0 ? trayStrip.lastControl : strip.available ? strip.list.currentItem : null
        rightTarget: batteryButton.visible ? batteryButton : quickSettings
        KeyNavigation.backtab: leftTarget
        KeyNavigation.tab: rightTarget
        onClicked: root.quickSettingsRequested(audioButton)
        Keys.onEscapePressed: root.dismissed()
        contentItem: Item {
            Image {
                width: 20; height: 20
                anchors.verticalCenter: parent.verticalCenter
                anchors.left: parent.left
                source: root.audio && root.audio.muted ? "../../assets/icons/volume-muted.svg" : "../../assets/icons/volume.svg"
                opacity: root.audio && root.audio.available ? 1 : 0.45
            }
            Text {
                objectName: "barAudioValue"
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                visible: root.width >= 600
                text: !root.audio || !root.audio.available ? "—" : root.audio.muted ? "×" : Math.round(root.audio.volume) + "%"
                font: audioButton.font
                color: Theme.text
            }
        }
        background: Rectangle {
            color: audioButton.hovered ? Theme.surface : Theme.background
            Rectangle {
                anchors.fill: parent; anchors.margins: Metrics.focusWidth
                color: "transparent"; border.width: Metrics.focusWidth; border.color: Theme.focus
                visible: audioButton.activeFocus
            }
        }
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.NoButton
            onWheel: wheel => {
                if (root.audio && root.audio.available && wheel.angleDelta.y !== 0) {
                    root.audio.changeVolume(wheel.angleDelta.y > 0 ? 5 : -5, root.screenName);
                    wheel.accepted = true;
                } else wheel.accepted = false;
            }
        }
    }
    UI.NavigationButton {
        id: networkButton
        objectName: "barNetwork"
        anchors.right: audioButton.left
        visible: root.network !== null && root.width >= 480
        width: visible ? (root.width >= 1000 ? 88 : Metrics.barStatusReserve) : 0
        height: parent.height
        padding: Metrics.space8
        text: root.network ? root.network.statusText : ""
        tooltip: text
        windowedTooltip: root.windowedTooltips
        leftTarget: trayStrip.width > 0 ? trayStrip.lastControl : strip.available ? strip.list.currentItem : null
        rightTarget: audioButton.visible ? audioButton : batteryButton.visible ? batteryButton : quickSettings
        KeyNavigation.backtab: leftTarget
        KeyNavigation.tab: rightTarget
        onClicked: root.quickSettingsRequested(networkButton)
        Keys.onEscapePressed: root.dismissed()
        onVisibleChanged: { if (!visible && activeFocus) quickSettings.forceActiveFocus(Qt.TabFocusReason); }
        contentItem: Item {
            Image {
                width: 20; height: 20; anchors.left: parent.left; anchors.verticalCenter: parent.verticalCenter
                source: "../../assets/icons/network.svg"
                opacity: root.network && (root.network.ethernetConnected || root.network.activeWifi.length) ? 1 : 0.45
            }
            Text {
                anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                visible: root.width >= 1000
                text: root.network ? root.network.indicator : "—"
                textFormat: Text.PlainText; font: networkButton.font; color: Theme.text
            }
        }
        background: Rectangle {
            color: networkButton.hovered ? Theme.surface : Theme.background
            Rectangle {
                anchors.fill: parent; anchors.margins: Metrics.focusWidth
                color: "transparent"; border.width: Metrics.focusWidth; border.color: Theme.focus
                visible: networkButton.activeFocus
            }
        }
    }
    UI.NavigationButton {
        id: quickSettings
        objectName: "quickSettingsButton"
        anchors.right: clock.left
        width: Metrics.barStatusReserve
        height: parent.height
        padding: Metrics.space8
        text: qsTr("Szybkie ustawienia")
        tooltip: root.panelActive ? qsTr("Zamknij panel") : text
        highlighted: root.panelActive
        windowedTooltip: root.windowedTooltips
        leftTarget: batteryButton.visible ? batteryButton : audioButton.visible ? audioButton : networkButton.visible ? networkButton : trayStrip.width > 0 ? trayStrip.lastControl : strip.available ? strip.list.currentItem : null
        KeyNavigation.backtab: leftTarget
        KeyNavigation.tab: strip.available ? strip.list.currentItem : quickSettings
        onClicked: root.quickSettingsRequested(quickSettings)
        Keys.onEscapePressed: root.dismissed()
        contentItem: Item {
            Column {
                anchors.centerIn: parent
                spacing: 3
                Repeater {
                    model: 3
                    Rectangle {
                        required property int index
                        width: 18
                        height: 2
                        color: quickSettings.foreground
                        Rectangle {
                            x: parent.index === 1 ? 11 : 4
                            y: -1
                            width: 3
                            height: 4
                            color: quickSettings.foreground
                        }
                    }
                }
            }
        }
        background: Rectangle {
            color: root.panelActive ? Theme.accent : quickSettings.hovered ? Theme.surface : Theme.background
            Rectangle {
                objectName: "focusIndicator"
                anchors.fill: parent
                anchors.margins: Metrics.focusWidth
                color: "transparent"
                border.width: Metrics.focusWidth
                border.color: root.panelActive ? Theme.accentText : Theme.focus
                visible: quickSettings.activeFocus
            }
        }
    }
}
