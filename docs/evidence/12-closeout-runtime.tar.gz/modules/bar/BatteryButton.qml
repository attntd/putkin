import QtQuick
import "../../core"
import "../../components" as UI

UI.NavigationButton {
    id: root
    required property var battery
    property bool compact: false
    readonly property color statusColor: battery && battery.warningLevel === 2 ? Theme.error
        : battery && battery.warningLevel === 1 ? Theme.warning : Theme.text
    text: battery ? battery.statusText : ""
    padding: Metrics.space8
    height: Metrics.barHeight
    width: compact ? Metrics.barStatusReserve : 88
    foreground: statusColor
    fillColor: hovered ? Theme.surface : Theme.background
    contentItem: Item {
        Rectangle {
            width: 18; height: 12
            anchors.left: parent.left; anchors.verticalCenter: parent.verticalCenter
            color: "transparent"; border.color: root.statusColor; border.width: Metrics.borderWidth
            Rectangle { width: 2; height: 6; x: parent.width; y: 3; color: root.statusColor }
            Rectangle {
                x: 3; y: 3; height: 6
                width: root.battery && root.battery.percentage >= 0 ? 12 * root.battery.percentage / 100 : 0
                color: root.statusColor
            }
            Text {
                anchors.centerIn: parent
                text: root.battery && root.battery.warningLevel ? "!" : root.battery && root.battery.charging ? "+" : root.battery && root.battery.state === 0 ? "?" : ""
                color: Theme.backgroundStrong
                style: Text.Outline; styleColor: root.statusColor
                font.bold: true; font.pixelSize: Metrics.smallFontSize
            }
        }
        Text {
            anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
            visible: !root.compact
            text: root.battery ? root.battery.percentageText : ""
            color: root.statusColor; font: root.font
        }
    }
    background: Rectangle {
        color: root.fillColor
        Rectangle {
            anchors.fill: parent; anchors.margins: Metrics.focusWidth
            color: "transparent"; border.color: Theme.focus; border.width: Metrics.focusWidth
            visible: root.activeFocus
        }
    }
}
