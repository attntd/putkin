import QtQuick
import QtQuick.Controls.Basic as Controls
import "../../components" as UI
import "../../core"

Controls.Control {
    id: root
    required property date date
    property int dateStyle: 2
    property bool windowedTooltip: false
    readonly property string timeText: date.toLocaleTimeString(locale, locale.timeFormat(Locale.ShortFormat).replace(/([:.\s])s{1,2}/g, ""))
    readonly property string dateText: dateStyle === 0 ? "" : (dateStyle === 2 ? date.toLocaleDateString(locale, "ddd") + " " : "") + date.toLocaleDateString(locale, Locale.ShortFormat)
    readonly property string fullDate: date.toLocaleDateString(locale, Locale.LongFormat)
    readonly property string label: (dateText.length > 0 ? dateText + "  " : "") + timeText

    objectName: "clock"
    implicitWidth: labelText.implicitWidth + Metrics.space16
    implicitHeight: Metrics.barHeight
    padding: Metrics.space8
    verticalPadding: 0
    hoverEnabled: true
    Accessible.role: Accessible.StaticText
    Accessible.name: fullDate + " " + timeText
    contentItem: Text {
        id: labelText
        text: root.label
        color: Theme.text
        font.family: Theme.fontFamily
        font.pixelSize: Metrics.fontSize
        verticalAlignment: Text.AlignVCenter
    }
    UI.ToolTip {
        objectName: "dateTooltip"
        visible: root.hovered
        text: root.fullDate
        popupType: root.windowedTooltip ? Controls.Popup.Window : Controls.Popup.Item
    }
}
