-- Hyprland 0.56.2. Pass the registry's bind and the installed shell.qml path.
return function(bind, shell_path)
    assert(type(shell_path) == "string" and shell_path:sub(1, 1) == "/",
        "Putkin requires an absolute shell.qml path")
    assert(not shell_path:find("%z") and not shell_path:find("\n"),
        "Invalid Putkin path")
    local quoted_path = "'" .. shell_path:gsub("'", "'\\''") .. "'"
    local ipc = "quickshell ipc --path " .. quoted_path .. " call "
    local menus = {
        {"SUPER + B", "bar focus", "Pasek"},
        {"SUPER + SHIFT + B", "bar focus", "Pasek"},
        {"SUPER + SHIFT + Q", "ui toggleQuickSettings", "Szybkie ustawienia"},
        {"SUPER + SHIFT + P", "session openPower", "Zasilanie"},
        {"SUPER + SHIFT + N", "notifications focus", "Powiadomienia"},
    }
    for _, menu in ipairs(menus) do
        bind(menu[1], hl.dsp.exec_cmd(ipc .. menu[2]),
            {description = "[Putkin] " .. menu[3]})
    end
end
