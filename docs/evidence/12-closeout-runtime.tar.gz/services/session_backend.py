"""Event-driven login1 / verified Hypridle bridge. JSON lines are private to QML.

No shell commands, PAM, persistent state or automatic retry of an action.
The trusted ScreenSaver owner is pinned for the entire lock transaction.
"""
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

import dbus
from dbus.mainloop.glib import DBusGMainLoop
from gi.repository import GLib

from session_lock import display_key, process_environment, launch

LOGIN = "org.freedesktop.login1"
MANAGER = LOGIN + ".Manager"
SESSION = LOGIN + ".Session"
LOGIN_PATH = "/org/freedesktop/login1"
SAVER = "org.freedesktop.ScreenSaver"
SAVER_PATH = "/org/freedesktop/ScreenSaver"
PROPERTIES = "org.freedesktop.DBus.Properties"
MISSING_CONFIRMATION = "Brak Hypridle 0.1.8 z potwierdzeniem blokady w tej sesji (org.freedesktop.ScreenSaver)."


class SessionBackend:
    lock_timeout_ms = 7000
    action_timeout = 8

    def __init__(self, emit):
        self.emit = emit
        self.system = dbus.SystemBus()
        self.session = dbus.SessionBus()
        self.login_owner = ""
        self.idle_owner = ""
        self.session_id = ""
        self.session_path = ""
        self.pending = None
        self.timer = 0
        self.sleeping = False
        self.last_id = 0
        self.matches = []
        self.capabilities = {}
        for bus, name in [(self.system, LOGIN), (self.session, SAVER)]:
            self.matches.append(bus.add_signal_receiver(self.owner_changed, "NameOwnerChanged", "org.freedesktop.DBus",
                bus_name="org.freedesktop.DBus", path="/org/freedesktop/DBus", arg0=name))
        self.matches.append(self.system.add_signal_receiver(self.prepare_sleep, "PrepareForSleep", MANAGER,
            path=LOGIN_PATH, sender_keyword="sender"))
        self.matches.append(self.session.add_signal_receiver(self.active_changed, "ActiveChanged", SAVER,
            path=SAVER_PATH, sender_keyword="sender"))
        self.refresh()

    @staticmethod
    def method(bus, owner, path, interface, name):
        return bus.get_object(owner, path, introspect=False).get_dbus_method(name, interface)

    def login(self, name, *args, **kwargs):
        return self.method(self.system, self.login_owner, LOGIN_PATH, MANAGER, name)(*args, **kwargs)

    def verify_idle_owner(self, owner):
        """Reject another screensaver, another display and unreviewed versions.

        PID/exe identify the observer only. Readiness comes from its protocol
        state, not from the observer's or locker's existence.
        """
        pid = int(self.method(self.session, "org.freedesktop.DBus", "/org/freedesktop/DBus",
                              "org.freedesktop.DBus", "GetConnectionUnixProcessID")(owner, timeout=1))
        proc = Path(f"/proc/{pid}")
        binary = shutil.which("hypridle")
        if not binary or proc.stat().st_uid != os.getuid() or (proc / "exe").resolve() != Path(binary).resolve():
            return False
        env = process_environment(pid)
        if display_key(env) != display_key(os.environ):
            return False
        signature = os.environ.get("HYPRLAND_INSTANCE_SIGNATURE", "")
        if not signature or env.get("HYPRLAND_INSTANCE_SIGNATURE") != signature:
            return False
        version = subprocess.run([str(proc / "exe"), "--version"], capture_output=True, text=True, timeout=1.5)
        return version.returncode == 0 and version.stdout.strip() == "hypridle v0.1.8"

    def current_session(self):
        # Explicit XDG id also works from uwsm application units. Never use
        # login1's "auto" fallback or terminate a whole user/seat.
        identifier = os.environ.get("XDG_SESSION_ID", "")
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", identifier):
            raise RuntimeError("Brak jednoznacznego XDG_SESSION_ID dla wylogowania.")
        path = str(self.login("GetSession", dbus.String(identifier), timeout=1))
        values = self.method(self.system, self.login_owner, path, PROPERTIES, "GetAll")(SESSION, timeout=1)
        if (str(values.get("Id")) != identifier or int(values.get("User", [-1])[0]) != os.getuid()
                or not values.get("Active") or values.get("Remote") or values.get("Class") != "user"
                or values.get("Type") not in ("wayland", "tty")):
            raise RuntimeError("Nie potwierdzono własnej, aktywnej sesji lokalnej.")
        if not os.environ.get("HYPRLAND_INSTANCE_SIGNATURE") or not os.environ.get("WAYLAND_DISPLAY"):
            raise RuntimeError("Nie rozpoznano środowiska sesji Hyprlanda.")
        return identifier, path

    def refresh(self):
        if self.pending:
            return
        caps = {}
        self.login_owner = self.idle_owner = ""
        self.session_id = self.session_path = ""
        try:
            self.login_owner = str(self.system.get_name_owner(LOGIN))
            for action, method in [("reboot", "CanReboot"), ("poweroff", "CanPowerOff"), ("suspend", "CanSuspend")]:
                value = str(self.login(method, timeout=1))
                caps[action] = {"available": value in ("yes", "challenge"), "reason":
                    "Wymaga autoryzacji systemowej." if value == "challenge" else "" if value == "yes"
                    else "Brak uprawnień." if value == "no" else "Operacja nieobsługiwana przez logind."}
            try:
                self.session_id, self.session_path = self.current_session()
                caps["logout"] = {"available": True, "reason": ""}
            except (dbus.DBusException, RuntimeError, OSError) as error:
                caps["logout"] = {"available": False, "reason": str(error)}
        except dbus.DBusException:
            for action in ("logout", "reboot", "poweroff", "suspend"):
                caps[action] = {"available": False, "reason": "Logind niedostępny lub nie odpowiada."}
        try:
            owner = str(self.session.get_name_owner(SAVER))
            if self.verify_idle_owner(owner):
                self.method(self.session, owner, SAVER_PATH, SAVER, "GetActive")(timeout=1)
                self.idle_owner = owner
        except (dbus.DBusException, OSError, RuntimeError, ValueError, subprocess.SubprocessError):
            pass
        lock_reason = ""
        try:
            display_key(os.environ)
            if not shutil.which("hyprlock"):
                lock_reason = "Brak programu Hyprlock."
        except RuntimeError as error:
            lock_reason = str(error)
        caps["lock"] = {"available": not lock_reason, "reason": lock_reason or ("" if self.idle_owner else MISSING_CONFIRMATION)}
        if not self.idle_owner or lock_reason:
            caps["suspend"] = {"available": False, "reason": lock_reason or MISSING_CONFIRMATION}
        self.capabilities = caps
        self.emit({"state": caps, "session": self.session_id, "confirmation": bool(self.idle_owner)})

    def owner_changed(self, name, old, new):
        if (name == LOGIN and str(old) == self.login_owner) or (name == SAVER and str(old) == self.idle_owner):
            self.sleeping = False
            if self.pending:
                self.finish(False, "Usługa sesji zniknęła; operacja przerwana.")
        self.refresh()

    def prepare_sleep(self, sleeping, sender=None):
        if str(sender) != self.login_owner or not self.login_owner:
            return
        if sleeping:
            self.sleeping = True
        elif self.sleeping:
            self.sleeping = False
            self.emit({"resumed": True})

    def finish(self, success, message=""):
        if not self.pending:
            return
        identifier = self.pending["id"]
        self.pending = None
        if self.timer:
            GLib.source_remove(self.timer)
            self.timer = 0
        self.emit({"completed": identifier, "success": success, "message": message})

    def cancel(self, identifier):
        if self.pending and self.pending["id"] == identifier:
            self.finish(False, "Anulowano oczekiwanie. Wysłanej operacji systemowej nie można cofnąć.")

    def expired(self):
        self.timer = 0
        self.finish(False, "Nie potwierdzono blokady w terminie. Uśpienie nie zostało wysłane; Hyprlock pozostaje niezależny.")
        return False

    def request(self, identifier, action):
        if self.pending or identifier <= self.last_id or action not in ("lock", "logout", "reboot", "poweroff", "suspend"):
            self.emit({"completed": identifier, "success": False, "message": "Odrzucono powtórzone lub nieprawidłowe żądanie."})
            return
        self.last_id = identifier
        self.refresh()
        capability = self.capabilities[action]
        self.pending = {"id": identifier, "action": action, "phase": "action", "owner": self.idle_owner}
        if not capability["available"]:
            self.finish(False, capability["reason"])
            return
        if action in ("lock", "suspend"):
            self.pending["phase"] = "locking"
            self.pending["deadline"] = time.monotonic() + self.lock_timeout_ms / 1000
            self.timer = GLib.timeout_add(self.lock_timeout_ms, self.expired)
            self.emit({"progress": identifier, "phase": "locking"})
            try:
                # Query existing protocol state before launching another locker.
                if self.idle_owner and self.is_locked():
                    self.locked(identifier)
                    return
                child = launch()
                if child:
                    GLib.child_watch_add(GLib.PRIORITY_DEFAULT, child.pid,
                        lambda _pid, status: self.locker_exited(identifier, child, status))
            except (OSError, RuntimeError, dbus.DBusException) as error:
                self.finish(False, str(error))
        else:
            self.perform(identifier)

    def locker_exited(self, identifier, child, status):
        child.returncode = os.waitstatus_to_exitcode(status)
        if self.pending and self.pending["id"] == identifier and self.pending["phase"] == "locking":
            self.finish(False, "Hyprlock zakończył się bez potwierdzenia blokady.")

    def is_locked(self):
        owner = self.pending["owner"]
        if not owner or str(self.session.get_name_owner(SAVER)) != owner:
            return False
        return bool(self.method(self.session, owner, SAVER_PATH, SAVER, "GetActive")(timeout=1))

    def active_changed(self, active, sender=None):
        pending = self.pending
        if pending and pending["phase"] == "locking" and active and str(sender) == pending["owner"]:
            self.locked(pending["id"])

    def locked(self, identifier):
        pending = self.pending
        if not pending or pending["id"] != identifier or pending["phase"] != "locking":
            return
        if time.monotonic() >= pending["deadline"]:
            self.finish(False, "Nie potwierdzono blokady w terminie. Uśpienie nie zostało wysłane.")
            return
        try:
            if not self.is_locked():
                return
        except dbus.DBusException:
            self.finish(False, "Utracono potwierdzenie blokady.")
            return
        if time.monotonic() >= pending["deadline"]:
            self.finish(False, "Potwierdzenie blokady przyszło po terminie. Nie wysłano uśpienia.")
            return
        # A signal from the pinned Hypridle owner plus a current GetActive,
        # or GetActive for an already locked session, is protocol evidence.
        self.emit({"progress": identifier, "phase": "locked"})
        if pending["action"] == "lock":
            self.finish(True, "Blokada potwierdzona przez Hypridle.")
        else:
            pending["phase"] = "action"
            if self.timer:
                GLib.source_remove(self.timer)
                self.timer = 0
            self.perform(identifier)

    def perform(self, identifier):
        if not self.pending or self.pending["id"] != identifier:
            return
        action = self.pending["action"]
        try:
            if str(self.system.get_name_owner(LOGIN)) != self.login_owner:
                raise RuntimeError("Zmieniła się usługa logind.")
            if action == "suspend" and not self.is_locked():
                raise RuntimeError("Blokada nie jest już potwierdzona; odmowa uśpienia.")
            if action == "suspend" and time.monotonic() >= self.pending["deadline"]:
                raise RuntimeError("Potwierdzenie blokady przyszło po terminie. Nie wysłano uśpienia.")
            if action == "logout":
                session_id, _ = self.current_session()
                method, args = "TerminateSession", [dbus.String(session_id)]
            else:
                method = {"poweroff": "PowerOff", "reboot": "Reboot", "suspend": "Suspend"}[action]
                args = [dbus.Boolean(True)]
            self.emit({"progress": identifier, "phase": "dispatching"})
            def reply(*_args):
                if self.pending and self.pending["id"] == identifier:
                    self.finish(True, "Logind przyjął żądanie.")
            def error(value):
                if self.pending and self.pending["id"] == identifier:
                    name = value.get_dbus_name()
                    uncertain = name in ("org.freedesktop.DBus.Error.NoReply", "org.freedesktop.DBus.Error.Timeout")
                    self.finish(False, "Brak wyniku logind; operacja mogła zostać przyjęta. Nie ponowiono." if uncertain
                                else "Logind odrzucił operację: " + name)
            self.login(method, *args, timeout=self.action_timeout, reply_handler=reply, error_handler=error)
        except (dbus.DBusException, RuntimeError) as error:
            self.finish(False, str(error))

    def command(self, value):
        if value.get("action") == "refresh":
            self.refresh()
        elif type(value.get("id")) is int and 0 < value["id"] < 2147483647:
            if value.get("action") == "cancel":
                self.cancel(value["id"])
            else:
                self.request(value["id"], value.get("action"))


def main(backend_class=SessionBackend):
    DBusGMainLoop(set_as_default=True)
    loop = GLib.MainLoop()
    backend = backend_class(lambda value: print(json.dumps(value, ensure_ascii=False), flush=True))
    buffer = bytearray()
    def input_ready(_fd, condition):
        if condition & (GLib.IO_HUP | GLib.IO_ERR):
            loop.quit()
            return False
        data = os.read(sys.stdin.fileno(), 4096)
        if not data:
            loop.quit()
            return False
        buffer.extend(data)
        if len(buffer) > 8192:
            loop.quit()
            return False
        while b"\n" in buffer:
            line, _, rest = buffer.partition(b"\n")
            buffer[:] = rest
            try:
                value = json.loads(line)
                if isinstance(value, dict):
                    backend.command(value)
            except (ValueError, TypeError):
                loop.quit()
                return False
        return True
    GLib.io_add_watch(sys.stdin.fileno(), GLib.IO_IN | GLib.IO_HUP | GLib.IO_ERR, input_ready)
    loop.run()


if __name__ == "__main__":
    main()
