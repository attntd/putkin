import QtQuick
import Quickshell.Services.Pipewire

QtObject {
    id: root
    readonly property bool ready: Pipewire.ready
    readonly property var outputs: Pipewire.nodes.values.filter(node => node.isSink && !node.isStream && node.audio !== null)
    readonly property var defaultOutput: Pipewire.defaultAudioSink
    property var snapshot: null
    property bool refreshing: false
    property var queuedVolume: null
    property var queuedMute: null

    // Only the default output needs live channel data. Names/type of other
    // nodes do not need tracking; the list preserves native object identity.
    readonly property PwObjectTracker tracker: PwObjectTracker { objects: [] }
    function reset(): void {
        verifyRead.stop();
        refreshing = false;
        queuedVolume = null;
        queuedMute = null;
        snapshot = null;
        tracker.objects = ready && defaultOutput ? [defaultOutput] : [];
        Qt.callLater(publish);
    }
    function publish(): void {
        if (!ready || !defaultOutput || !defaultOutput.ready || !defaultOutput.audio) return;
        if (queuedVolume !== null || queuedMute !== null) {
            flush();
            return;
        }
        if (refreshing) return;
        const audio = defaultOutput.audio;
        if (audio.channels.length === 0 || !isFinite(audio.volume)) return;
        snapshot = { node: defaultOutput, volume: audio.volume, muted: audio.muted };
    }
    function writeVolume(node: var, value: real): bool {
        if (!ready || node !== defaultOutput) return false;
        refreshing = true;
        queuedVolume = value;
        flush();
        return true;
    }
    function writeMuted(node: var, value: bool): bool {
        if (!ready || node !== defaultOutput) return false;
        refreshing = true;
        queuedMute = value;
        flush();
        return true;
    }
    function flush(): void {
        if (!defaultOutput || !defaultOutput.ready) return;
        if (queuedVolume !== null) {
            const value = queuedVolume;
            queuedVolume = null;
            defaultOutput.audio.volume = value;
        }
        if (queuedMute !== null) {
            const value = queuedMute;
            queuedMute = null;
            defaultOutput.audio.muted = value;
        }
        verifyRead.restart();
    }
    function selectOutput(node: var): bool {
        if (!ready || outputs.indexOf(node) < 0) return false;
        Pipewire.preferredDefaultAudioSink = node;
        return true;
    }
    // 0.3.1 setters emit optimistic changes and have no error/ack signal.
    // Rebind once after the command burst to enumerate actual server Props.
    // This timer never runs in idle. No wpctl, polling, or cached success.
    readonly property Timer verifyRead: Timer {
        interval: 100
        onTriggered: {
            root.tracker.objects = [];
            Qt.callLater(() => {
                if (root.ready && root.defaultOutput)
                    root.tracker.objects = [root.defaultOutput];
            });
        }
    }
    readonly property Connections nodeChanges: Connections {
        target: root.defaultOutput
        function onReadyChanged(): void {
            if (root.defaultOutput && root.defaultOutput.ready) {
                if (root.queuedVolume === null && root.queuedMute === null)
                    root.refreshing = false;
                Qt.callLater(root.publish);
            }
        }
    }
    readonly property Connections audioChanges: Connections {
        target: root.defaultOutput ? root.defaultOutput.audio : null
        function onVolumesChanged(): void { Qt.callLater(root.publish); }
        function onMutedChanged(): void { Qt.callLater(root.publish); }
        function onChannelsChanged(): void { Qt.callLater(root.publish); }
    }
    onReadyChanged: reset()
    onDefaultOutputChanged: reset()
    Component.onCompleted: reset()
}
