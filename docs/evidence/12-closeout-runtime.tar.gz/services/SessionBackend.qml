import QtQuick
import Quickshell
import Quickshell.Io

QtObject {
    id: root
    property string helperPath: Quickshell.shellPath("services/session_backend.py")
    property var helperEnvironment: ({})
    property var capabilities: ({})
    property string sessionId: ""
    property bool confirmationAvailable: false
    property bool ready: false
    property string errorText: ""
    property bool stopping: false
    property bool started: false
    readonly property int processId: worker.processId || 0
    signal completed(int requestId, bool success, string message)
    signal progress(int requestId, string phase)
    signal resumed()

    function send(value: var): void { worker.write(JSON.stringify(value) + "\n"); }
    function request(id: int, action: string): bool {
        if (!ready) return false;
        send({ id: id, action: action });
        return true;
    }
    function cancel(id: int): void { if (ready) send({ id: id, action: "cancel" }); }
    function refresh(): void { if (ready) send({ action: "refresh" }); }
    function fail(): void {
        ready = false;
        capabilities = {};
        confirmationAvailable = false;
        errorText = qsTr("Adapter sesji niedostępny. Sprawdź Python, python-dbus, python-gobject i D-Bus; uruchom ponownie Putkin.");
        startup.stop();
        if (worker.running && worker.processId > 0) worker.signal(9);
    }
    function receive(line: string): void {
        let value;
        try { value = JSON.parse(line); }
        catch (_) { fail(); return; }
        if (value.state !== undefined) {
            capabilities = value.state;
            sessionId = value.session;
            confirmationAvailable = value.confirmation;
            errorText = "";
            ready = true;
            startup.stop();
        } else if (value.completed !== undefined)
            completed(value.completed, value.success, value.message);
        else if (value.progress !== undefined)
            progress(value.progress, value.phase);
        else if (value.resumed === true)
            resumed();
    }
    readonly property Process worker: Process {
        command: ["python3", "-B", root.helperPath]
        environment: root.helperEnvironment
        stdinEnabled: true
        stdout: SplitParser { onRead: data => root.receive(data) }
        // Diagnostics stay in the Quickshell log; no passwords cross this pipe.
        stderr: SplitParser { onRead: data => { console.error("Session backend: " + data); root.fail(); } }
        onStarted: root.started = true
        onRunningChanged: { if (!running && !root.started && !root.stopping) root.fail(); }
    }
    readonly property Timer startup: Timer { interval: 12000; onTriggered: root.fail() }
    Component.onCompleted: {
        worker.exited.connect(() => { if (!root.stopping) root.fail(); });
        startup.start();
        worker.running = true;
    }
    Component.onDestruction: {
        stopping = true;
        if (worker.running && worker.processId > 0) worker.signal(9);
    }
}
