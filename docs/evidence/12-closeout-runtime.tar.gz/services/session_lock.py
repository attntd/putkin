"""Launch the external locker once per display; never claim lock readiness."""

import fcntl
import hashlib
import os
from pathlib import Path
import resource
import shutil
import stat
import subprocess


def display_key(env):
    runtime = Path(env.get("XDG_RUNTIME_DIR", ""))
    display = Path(env.get("WAYLAND_DISPLAY", ""))
    if not runtime.is_absolute() or not env.get("WAYLAND_DISPLAY"):
        raise RuntimeError("Brak sesji Wayland lub XDG_RUNTIME_DIR.")
    return str(display if display.is_absolute() else runtime / display)


def process_environment(pid):
    return dict(part.split("=", 1) for part in Path(f"/proc/{pid}/environ").read_text().split("\0") if "=" in part)


def launch():
    binary = shutil.which("hyprlock")
    if not binary:
        raise RuntimeError("Brak programu Hyprlock.")
    display = display_key(os.environ)
    directory = os.open(os.environ["XDG_RUNTIME_DIR"], os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        info = os.fstat(directory)
        if info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise RuntimeError("XDG_RUNTIME_DIR nie jest prywatnym katalogiem użytkownika.")
        name = "putkin-lock-" + hashlib.sha256(os.fsencode(display)).hexdigest()[:24]
        fd = os.open(name, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=directory)
    finally:
        os.close(directory)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1 or info.st_mode & 0o077:
            raise RuntimeError("Nieprawidłowy plik synchronizacji blokady.")
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return None
        # An externally launched Hyprlock is only a duplicate guard, NOT proof
        # of a locked session. Its exit/PID never authorizes suspend.
        for proc in Path("/proc").iterdir():
            if not proc.name.isdigit():
                continue
            try:
                if proc.stat().st_uid == os.getuid() and (proc / "exe").resolve() == Path(binary).resolve():
                    if display_key(process_environment(proc.name)) == display:
                        return None
            except (OSError, RuntimeError, ValueError):
                continue
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        # The child owns the flock after this helper exits/reloads. Do not
        # terminate it on cancellation, timeout or shell destruction.
        return subprocess.Popen([binary, "--grace", "0"], pass_fds=(fd,), start_new_session=True,
                                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    finally:
        os.close(fd)
