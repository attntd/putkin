import QtQuick

// The backend owns the connection; this model owns numbering and action sequencing.
QtObject {
    id: root

    required property var backend
    readonly property bool available: backend.connected && backend.monitors.length > 0
    readonly property var monitors: available ? backend.monitors : []
    readonly property string focusedMonitorName: available ? backend.focusedMonitorName : ""
    readonly property ListModel workspaces: ListModel {}
    readonly property var snapshot: makeSnapshot()
    property string lastError: ""
    property int pendingId: -1
    property string pendingMonitor: ""
    property bool activationSent: false
    readonly property bool busy: pendingId > 0
    property int actionTimeout: 2000

    signal updated()

    function monitorAvailable(name: string): bool {
        return monitors.some(monitor => monitor.name === name);
    }

    function activeId(name: string): int {
        const monitor = monitors.find(item => item.name === name);
        return monitor ? monitor.activeId : -1;
    }

    function indexOf(id: int): int {
        for (let i = 0; i < workspaces.count; ++i) {
            if (workspaces.get(i).workspaceId === id)
                return i;
        }
        return -1;
    }

    function makeSnapshot(): var {
        const entries = {};
        for (let id = 1; id <= 5; ++id)
            entries[id] = { workspaceId: id, occupied: false, urgent: false, visibleOn: "" };
        if (available) {
            for (const item of backend.workspaces) {
                if (item.id > 0 && (item.occupied || item.urgent || entries[item.id]))
                    entries[item.id] = { workspaceId: item.id, occupied: item.occupied, urgent: item.urgent, visibleOn: "" };
            }
            for (const monitor of monitors) {
                if (monitor.activeId <= 0)
                    continue;
                if (!entries[monitor.activeId])
                    entries[monitor.activeId] = { workspaceId: monitor.activeId, occupied: false, urgent: false, visibleOn: "" };
                entries[monitor.activeId].visibleOn = monitor.name;
            }
        }
        return Object.values(entries).sort((a, b) => a.workspaceId - b.workspaceId);
    }

    function syncModel(): void {
        // Retain delegates and their focus when only occupancy/urgency changes.
        for (let i = 0; i < snapshot.length; ++i) {
            const entry = snapshot[i];
            while (i < workspaces.count && workspaces.get(i).workspaceId < entry.workspaceId)
                workspaces.remove(i);
            if (i >= workspaces.count || workspaces.get(i).workspaceId !== entry.workspaceId)
                workspaces.insert(i, entry);
            else {
                for (const role of ["occupied", "urgent", "visibleOn"])
                    workspaces.setProperty(i, role, entry[role]);
            }
        }
        if (workspaces.count > snapshot.length)
            workspaces.remove(snapshot.length, workspaces.count - snapshot.length);
        advanceAction();
        updated();
    }

    function cancelAction(message: string): void {
        deadline.stop();
        pendingId = -1;
        pendingMonitor = "";
        activationSent = false;
        lastError = message;
    }

    function activate(id: int, monitorName: string): bool {
        if (!available || !monitorAvailable(monitorName)) {
            lastError = qsTr("Hyprland niedostępny");
            return false;
        }
        if (indexOf(id) < 0 || busy)
            return false;
        lastError = "";
        pendingMonitor = monitorName;
        pendingId = id;
        activationSent = false;
        deadline.restart();
        if (focusedMonitorName !== monitorName)
            backend.focusMonitor(monitorName);
        advanceAction();
        return true;
    }

    function advanceAction(): void {
        if (!busy)
            return;
        if (!monitorAvailable(pendingMonitor)) {
            cancelAction(qsTr("Monitor lub Hyprland niedostępny"));
            return;
        }
        if (activeId(pendingMonitor) === pendingId && focusedMonitorName === pendingMonitor) {
            cancelAction("");
            return;
        }
        if (!activationSent && focusedMonitorName === pendingMonitor) {
            activationSent = true;
            backend.activateWorkspace(pendingId);
        }
    }

    onSnapshotChanged: syncModel()
    onFocusedMonitorNameChanged: advanceAction()
    onMonitorsChanged: advanceAction()
    Component.onCompleted: syncModel()

    readonly property Timer deadline: Timer {
        interval: root.actionTimeout
        onTriggered: root.cancelAction(qsTr("Hyprland nie potwierdził zmiany workspace"))
    }
}
