import QtQml
import Quickshell.Io

QtObject {
    id: root
    required property var service
    required property var coordinator
    readonly property IpcHandler handler: IpcHandler {
        target: "session"
        function openPower(): string {
            return root.coordinator.open("power", null, null) ? "ok" : root.coordinator.lastError;
        }
        function lock(): string { return root.service.request("lock") ? "accepted" : root.service.busy ? "busy" : root.service.lastError; }
        function status(): string {
            return JSON.stringify({ busy: root.service.busy, phase: root.service.phase, error: root.service.lastError,
                result: root.service.resultText, capabilities: root.service.capabilities });
        }
    }
}
