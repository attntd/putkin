import QtQuick

QtObject {
    id: root
    required property var backend
    readonly property var outputs: backend.ready ? backend.outputs : []
    readonly property var defaultOutput: backend.ready ? backend.defaultOutput : null
    readonly property var state: backend.snapshot
    readonly property bool available: backend.ready && defaultOutput !== null && state !== null
        && state.node === defaultOutput && outputs.indexOf(defaultOutput) >= 0
    // Unavailable is not 0%. External amplification is displayed honestly;
    // commands issued by Putkin are limited to 0–100%.
    readonly property real volume: available ? state.volume * 100 : -1
    readonly property bool muted: available && state.muted
    readonly property string outputName: defaultOutput ? label(defaultOutput) : ""
    readonly property string statusText: !backend.ready ? qsTr("Audio niedostępne")
        : !defaultOutput ? qsTr("Brak wyjścia audio")
        : !available ? qsTr("Odczytywanie wyjścia…")
        : muted ? qsTr("Wyciszone · %1%").arg(Math.round(volume)) : Math.round(volume) + "%"
    property string lastError: ""
    property var pending: null
    readonly property bool busy: pending !== null
    property int operationTimeout: 1800
    property var previous: null
    signal feedback(string monitor)

    function label(node: var): string { return node.description || node.nickname || node.name; }
    function reject(message: string): bool { lastError = message; return false; }
    function validNumber(value: var): bool { return typeof value === "number" && isFinite(value); }

    function setVolume(value: var, monitor: string): bool {
        if (!validNumber(value) || value < 0 || value > 100)
            return reject(qsTr("Głośność musi być liczbą od 0 do 100."));
        return requestLevel("volume", value / 100, monitor);
    }
    function changeVolume(delta: var, monitor: string): bool {
        if (!validNumber(delta) || Math.abs(delta) > 100)
            return reject(qsTr("Zmiana głośności musi być liczbą od −100 do 100."));
        const base = pending && pending.kind === "level" && pending.volume !== null ? pending.volume * 100 : volume;
        return setVolume(Math.max(0, Math.min(100, base + delta)), monitor);
    }
    function setMuted(value: var, monitor: string): bool {
        if (typeof value !== "boolean") return reject(qsTr("Niepoprawny stan wyciszenia."));
        return requestLevel("muted", value, monitor);
    }
    function toggleMute(monitor: string): bool {
        const base = pending && pending.kind === "level" && pending.muted !== null ? pending.muted : muted;
        return setMuted(!base, monitor);
    }
    function requestLevel(field: string, value: var, monitor: string): bool {
        if (!available) return reject(qsTr("Wyjście audio jest niedostępne."));
        if (pending && pending.kind === "output") return reject(qsTr("Trwa zmiana wyjścia audio."));
        const request = pending && pending.node === defaultOutput
            ? Object.assign({}, pending) : { kind: "level", node: defaultOutput, volume: null, muted: null };
        request[field] = value;
        request.monitor = monitor;
        pending = request;
        lastError = "";
        deadline.restart();
        const accepted = field === "volume" ? backend.writeVolume(request.node, value) : backend.writeMuted(request.node, value);
        if (!accepted) {
            fail(qsTr("Nie można zmienić stanu wyjścia audio."));
            return false;
        }
        Qt.callLater(sync);
        return true;
    }
    function selectOutput(node: var, monitor: string): bool {
        if (!backend.ready || outputs.indexOf(node) < 0)
            return reject(qsTr("Wybrane wyjście nie jest już dostępne."));
        pending = { kind: "output", node: node, monitor: monitor };
        lastError = "";
        deadline.restart();
        if (!backend.selectOutput(node)) {
            fail(qsTr("Nie można wybrać wyjścia audio."));
            return false;
        }
        Qt.callLater(sync);
        return true;
    }
    function fail(message: string): void {
        deadline.stop();
        pending = null;
        lastError = message;
    }
    function sync(): void {
        const current = available ? state : null;
        let notified = false;
        if (pending) {
            if (!backend.ready || outputs.indexOf(pending.node) < 0
                    || (pending.kind === "level" && pending.node !== defaultOutput)) {
                fail(qsTr("Wyjście audio zniknęło lub zostało zmienione."));
            } else if (current && pending.node === current.node && !backend.refreshing
                    && (pending.kind === "output" || ((pending.volume === null || Math.abs(current.volume - pending.volume) < 0.005)
                        && (pending.muted === null || pending.muted === current.muted)))) {
                const monitor = pending.monitor;
                deadline.stop();
                pending = null;
                lastError = "";
                feedback(monitor);
                notified = true;
            }
        }
        // First sample, reconnect, and a new default output establish a baseline.
        if (!notified && !pending && current && previous && previous.node === current.node
                && (Math.abs(previous.volume - current.volume) > 0.0001 || previous.muted !== current.muted))
            feedback("");
        previous = current;
    }
    readonly property Timer deadline: Timer {
        interval: root.operationTimeout
        onTriggered: root.fail(qsTr("Backend nie potwierdził zmiany audio. Spróbuj ponownie."))
    }
    readonly property Connections changes: Connections {
        target: root.backend
        function onSnapshotChanged(): void { Qt.callLater(root.sync); }
        function onReadyChanged(): void { Qt.callLater(root.sync); }
        function onDefaultOutputChanged(): void { Qt.callLater(root.sync); }
        function onOutputsChanged(): void { Qt.callLater(root.sync); }
        function onRefreshingChanged(): void { Qt.callLater(root.sync); }
    }
    Component.onCompleted: Qt.callLater(sync)
}
